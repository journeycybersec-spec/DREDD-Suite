#!/usr/bin/env python3
import os
import subprocess
import sys

print("\n====================================")
print("   DreddSuite Python Installer")
print("====================================\n")

# -------------------------------------------------
# Check Python version
# -------------------------------------------------
if sys.version_info.major < 3:
    print("ERROR: Python 3 is required.")
    sys.exit(1)

project_root = os.path.dirname(os.path.abspath(__file__))
venv_path = os.path.join(project_root, "venv")

# -------------------------------------------------
# Create venv
# -------------------------------------------------
if not os.path.exists(venv_path):
    print("[+] Creating virtual environment...")
    subprocess.run([sys.executable, "-m", "venv", "venv"], check=True)
else:
    print("[+] Virtual environment already exists.")

# -------------------------------------------------
# Activate venv + install pip packages
# -------------------------------------------------
pip_exec = os.path.join(venv_path, "bin", "pip")

print("[+] Upgrading pip...")
subprocess.run([pip_exec, "install", "--upgrade", "pip"], check=True)

req_file = os.path.join(project_root, "requirements.txt")

if not os.path.isfile(req_file):
    print("ERROR: requirements.txt not found!")
    sys.exit(1)

print("[+] Installing requirements...")
subprocess.run([pip_exec, "install", "-r", req_file], check=True)

# -------------------------------------------------
# Create launcher script
# -------------------------------------------------
launcher = os.path.join(project_root, "run_dreddsuite.sh")

print("[+] Creating launcher script...")

with open(launcher, "w") as f:
    f.write("#!/usr/bin/env bash\n")
    f.write("source venv/bin/activate\n")
    f.write("python3 DreddSuiteLauncher.py\n")

os.chmod(launcher, 0o755)

print("\n====================================")
print("   Installation Complete!")
print(" Run with: ./run_dreddsuite.sh")
print("====================================\n")
