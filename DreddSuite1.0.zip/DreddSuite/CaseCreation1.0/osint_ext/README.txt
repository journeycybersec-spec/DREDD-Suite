osint_ext package

What is this?
- Add-on to your existing profile.py. Do NOT edit profile.py.
- Provides three options: prompt export, local Ollama run, optional Claude API run.

Install:
- Place 'osint_ext' folder next to your profile.py.
- (Claude only) pip install requests

Usage:
1) Generate prompt for copy/paste:
   python3 -m osint_ext.ai_cli prompt --project ./my_target

2) Run locally via Ollama (no external API):
   # install ollama + model once: ollama pull llama3.1:8b
   python3 -m osint_ext.ai_cli run-ollama --project ./my_target --model llama3.1:8b

3) Run via Claude API (optional):
   export ANTHROPIC_API_KEY=sk-...   # your key
   python3 -m osint_ext.ai_cli run-claude --project ./my_target --model claude-3-sonnet-20240229

Outputs:
- Prompts: <project>/exports/prompts/LATEST_prompt.md (plus timestamped copies)
- Results: <project>/exports/ai/LATEST_result.md (plus timestamped copies)
Generated: 2025-11-22T17:40:54
