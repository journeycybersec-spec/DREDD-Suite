"""
osint_ext: AI integration addons for the OSINT profile tool.
- Keep profile.py untouched.
- Use ai_cli.py for prompts + optional Claude API + local Ollama runs.
"""