from __future__ import annotations
import json
import re
from typing import Any, Tuple

SMART_QUOTES = {
    '\u201c': '"', '\u201d': '"', '\u201e': '"', '\u201f': '"',
    '\u2018': "'", '\u2019': "'", '\u2032': "'", '\u2033': '"',
}

def _desmart(s: str) -> str:
    for k, v in SMART_QUOTES.items():
        s = s.replace(k, v)
    return s

def _strip_code_fences(s: str) -> str:
    # remove ```json ... ``` fences if present
    s = re.sub(r"```json\s*([\s\S]*?)\s*```", r"\1", s, flags=re.IGNORECASE)
    s = re.sub(r"```\s*([\s\S]*?)\s*```", r"\1", s)
    return s.strip()

def _remove_trailing_commas(s: str) -> str:
    # remove trailing commas before } or ]
    s = re.sub(r",\s*([}\]])", r"\1", s)
    return s

def _first_json_block(text: str) -> str | None:
    # Prefer fenced block first
    m = re.search(r"```json\s*([\s\S]*?)\s*```", text, flags=re.IGNORECASE)
    if m:
        return m.group(1).strip()
    m = re.search(r"```\s*([\s\S]*?)\s*```", text)
    if m:
        return m.group(1).strip()
    # Fallback: find first { ... } balanced block
    start = text.find('{')
    if start == -1:
        return None
    depth = 0
    in_str = False
    esc = False
    for i in range(start, len(text)):
        ch = text[i]
        if in_str:
            if not esc and ch == '"':
                in_str = False
            esc = (ch == '\\' and not esc)
        else:
            if ch == '"':
                in_str = True
            elif ch == '{':
                depth += 1
            elif ch == '}':
                depth -= 1
                if depth == 0:
                    return text[start:i+1]
    return None

def extract_and_fix_json(raw: str) -> Tuple[str, Any]:
    """Return (json_text, parsed_obj). Raises ValueError if cannot parse."""
    candidate = _first_json_block(raw)
    if not candidate:
        raise ValueError("No JSON found in text.")
    candidate = _desmart(candidate)
    candidate = _strip_code_fences(candidate)
    for _ in range(2):
        try:
            return (candidate, json.loads(candidate))
        except json.JSONDecodeError:
            candidate = _remove_trailing_commas(candidate)
    # last attempt: common replacement of single quotes (risky, so only if it looks like JSON-ish)
    if "'" in candidate and '"' not in candidate:
        candidate2 = candidate.replace("'", '"')
        try:
            return (candidate2, json.loads(candidate2))
        except json.JSONDecodeError:
            pass
    raise ValueError("Unable to parse JSON after fixes.")
