# Custom OSINT Prompt ({{NOW}})

Use the following company JSON:
```json
{{PROFILE_JSON}}
```

## Tasks
{{TASKS}}

## Constraints
{{CONSTRAINTS}}

## Output Schema
```json
{{SCHEMA}}
```

## Notes
- Return one JSON object only (no extra prose).
- Include source/evidence next to each item.
