from __future__ import annotations
import json
from pathlib import Path
from typing import Any, Dict
import textwrap
import datetime

# ---------- IO helpers ----------
def read_profile(project: Path) -> Dict[str, Any]:
    path = project / "profile.json"
    if not path.exists():
        raise FileNotFoundError(f"Profile not found: {path}")
    return json.loads(path.read_text(encoding="utf-8"))

def ensure_exports(project: Path) -> Path:
    out = project / "exports"
    out.mkdir(parents=True, exist_ok=True)
    return out

def ensure_dirs(project: Path) -> dict[str, Path]:
    root = ensure_exports(project)
    d = {
        "prompts": root / "prompts",
        "results": root / "ai",
    }
    for p in d.values():
        p.mkdir(parents=True, exist_ok=True)
    return d

def now_stamp() -> str:
    return datetime.datetime.now().strftime("%Y-%m-%d_%H%M%S")

def write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")

def update_latest(stamped: Path, latest_name: str) -> Path:
    """Keep a LATEST_* companion; fallback to copy if symlink unsupported."""
    latest = stamped.parent / latest_name
    try:
        if latest.exists() or latest.is_symlink():
            latest.unlink()
        latest.symlink_to(stamped.name)
    except Exception:
        write_text(latest, stamped.read_text(encoding="utf-8"))
    return latest

# ---------- Prompt components ----------
def _pretty_json(d: Dict[str, Any]) -> str:
    return json.dumps(d, indent=2, ensure_ascii=False)

def _default_tasks() -> str:
    return textwrap.dedent("""      1) Enumerate internet footprint: domains, subdomains, IPs, hosting, SSL.
      2) Profile org & people: executives, founders, officers, public-facing staff.
      3) Map platforms: official + likely brand accounts (LinkedIn/Twitter/Facebook/YouTube/GitHub/apps).
      4) Assess security signals: breaches, phishing domains, risky misconfigs.
      5) List investors/funding and any payment/banking disclosures.
      6) Callout and make a list of red flags that should be considered high risk and explain why its a high risk.
      7) Make sure to cite all sources while doing your investigations.
      8) Provide prioritized next steps (specific queries/tools).""")

def _default_constraints() -> str:
    return textwrap.dedent("""      - Open-source only; no intrusion or non-consensual access.
      - Prefer primary sources; include working links.
      - Be explicit; mark assumptions.
      - Return one JSON object matching the schema exactly (no extra prose).""")

def _default_schema() -> str:
    return textwrap.dedent("""      {
        "targets": {
          "domains": ["..."],
          "subdomains": ["..."],
          "ips": ["..."],
          "people": [{"name":"...", "role":"...", "source":"..."}],
          "platforms": [{"type":"linkedin|github|twitter|...", "url":"...", "source":"..."}],
          "infrastructure": [{"asset":"...", "evidence":"...", "source":"..."}]
        },
        "intel_findings": [
          {"title":"...", "summary":"...", "risk":"low|med|high", "evidence":["..."], "sources":["..."]}
        ],
        "security_signals": {
          "breaches": [{"vendor":"...", "date":"...", "source":"..."}],
          "phishing": [{"domain":"...", "status":"active|parked", "source":"..."}]
        },
        "gaps_and_next_steps": ["..."],
        "citations": ["..."]
      }""")

# ---------- Template helpers ----------
def _fill_template(tpl: str, mapping: Dict[str, str]) -> str:
    # Simple {{KEY}} replacement; avoids str.format() brace collisions with JSON
    for k, v in mapping.items():
        tpl = tpl.replace(f"{{{{{k}}}}}", v)
    return tpl

def render_prompt(profile: Dict[str, Any], template_path: str | None = None) -> str:
    """Build the OSINT prompt. Supports external template with placeholders."""
    ctx_json = _pretty_json(profile)
    tasks = _default_tasks()
    constraints = _default_constraints()
    schema = _default_schema()
    now = datetime.datetime.now().isoformat(timespec="seconds")

    if template_path:
        tpl = Path(template_path).expanduser().read_text(encoding="utf-8")
        return _fill_template(tpl, {
            "PROFILE_JSON": ctx_json,
            "TASKS": tasks,
            "CONSTRAINTS": constraints,
            "SCHEMA": schema,
            "NOW": now,
        })

    # Built-in default template
    return f"""# OSINT Investigation Prompt

Use the company JSON below to plan and conduct an OSINT investigation. Produce actionable findings and concrete next steps.
Return **one JSON object only** that matches the schema exactly.

## Company Context (JSON)
```json
{ctx_json}
```

## Tasks
{tasks}

## Constraints
{constraints}

## Output Schema (return a single JSON object)
```json
{schema}
```

## Notes
- If fields are empty/missing, suggest next steps; do not fabricate facts.
- Include **source/evidence** next to each listed item.
- Once finished, reproduce your entire investigation in human readable format.
"""

def save_prompt_files(project: Path, prompt_md: str) -> tuple[Path, Path]:
    """Write a timestamped prompt and a LATEST pointer."""
    dirs = ensure_dirs(project)
    stamp = now_stamp()
    stamped = dirs["prompts"] / f"{stamp}_prompt.md"
    write_text(stamped, prompt_md)
    latest = update_latest(stamped, "LATEST_prompt.md")
    return stamped, latest
