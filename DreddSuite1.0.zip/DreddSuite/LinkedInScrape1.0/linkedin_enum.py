#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LinkedIn Employee Enumerator v4
-------------------------------

Features:
- Uses local SearXNG (HTML mode) to enumerate LinkedIn profiles
- Large OSINT dork pack (FULL enumeration mode)
- User-selected pagination depth (0..N, step 10)
- Rotating User-Agents + jittered delays
- Universal snippet extraction from SearXNG HTML
- Optional "current employees only" soft filter (snippet-based)
- Tracks which dorks produced the most profiles
- Exports CSV + JSON of discovered profile URLs

Note:
Per your requirement, this version DOES NOT include
"current employee specific" dorks like:
  - "works at {company}"
  - "current {company}"
  - "present {company}"
"""

import requests
import re
import json
import csv
import time
import os
import random
from datetime import datetime
from bs4 import BeautifulSoup

# ================================
# CONFIGURATION
# ================================
SEARX_INSTANCE = "http://localhost:8080"
REQUEST_TIMEOUT = 12

GREEN = "\033[92m"
RED = "\033[91m"
CYAN = "\033[96m"
RESET = "\033[0m"

USER_AGENTS = [
    # Firefox
    "Mozilla/5.0 (X11; Linux x86_64; rv:128.0) Gecko/20100101 Firefox/128.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0",
    # Chrome
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/123.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/123.0 Safari/537.36",
    # Safari (Mac spoof)
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 "
    "(KHTML, like Gecko) Version/17 Safari/605.1.15",
]


# ================================
# LINKEDIN PROFILE REGEX
# ================================
PROFILE_REGEX = re.compile(
    r"https?://(?:www\.)?linkedin\.com/in/[A-Za-z0-9\-\_/%]+",
    re.IGNORECASE,
)


# ================================
# ADVANCED DORK PACK (FULL MODE)
# ================================
def build_dorks(company: str) -> list[str]:
    """
    Build a large, structured OSINT dork set for LinkedIn employee discovery.
    Does NOT include explicit 'current employee' phrases like 'works at', 'current', 'present'.
    """

    c = company.strip()

    # Base / general discovery
    base = [
        f'site:linkedin.com/in "{c}"',
        f'"{c}" "linkedin.com/in"',
        f'"{c}" employees "linkedin"',
        f'site:linkedin.com/in ("{c}" AND employee)',
        f'site:linkedin.com/in ("{c}" AND "profile")',
        f'site:linkedin.com/in ("{c}" AND "people")',
        f'site:linkedin.com/in ("{c}" AND "person")',
        f'site:linkedin.com/in ("{c}" AND "professional")',
        # Exclude obvious past-employee language at the dork level
        f'site:linkedin.com/in "{c}" -former -past -previous -ex-',
    ]

    # Seniority / level
    seniority_terms = [
        "senior",
        "sr.",
        "sr ",
        "lead",
        "principal",
        "director",
        "vp",
        "vice president",
        "head of",
        "manager",
        "associate",
        "junior",
        "intern",
    ]
    seniority_dorks = [
        f'site:linkedin.com/in ("{c}" AND "{term}")' for term in seniority_terms
    ]

    # Roles / functions
    role_terms = [
        # Tech / product
        "engineer",
        "developer",
        "architect",
        "devops",
        "site reliability",
        "sre",
        "qa",
        "quality assurance",
        "product manager",
        "product owner",
        "scrum master",
        # Security / IT
        "security",
        "cybersecurity",
        "infosec",
        "network engineer",
        "systems engineer",
        "it manager",
        "it administrator",
        "system administrator",
        # Data / analytics
        "data scientist",
        "data engineer",
        "data analyst",
        "business analyst",
        "analytics",
        # Business / operations
        "operations",
        "project manager",
        "program manager",
        "consultant",
        "specialist",
        "coordinator",
        "administrator",
        "account manager",
        "customer success",
        "sales",
        "marketing",
        "growth",
        "business development",
        # Execs
        "ciso",
        "cio",
        "cto",
        "ceo",
        "cfo",
        "chief",
        # Healthcare-ish
        "clinical",
        "healthcare",
        "nurse",
        "physician",
        "case manager",
    ]
    role_dorks = [
        f'site:linkedin.com/in ("{c}" AND "{role}")' for role in role_terms
    ]

    # OR-based combined dorks (high yield)
    or_role_dorks = [
        f'site:linkedin.com/in ("{c}" AND ("engineer" OR "developer" OR "architect"))',
        f'site:linkedin.com/in ("{c}" AND ("security" OR "cybersecurity" OR "infosec"))',
        f'site:linkedin.com/in ("{c}" AND ("data scientist" OR "data engineer" OR "data analyst"))',
        f'site:linkedin.com/in ("{c}" AND ("manager" OR "director" OR "lead" OR "vp"))',
        f'site:linkedin.com/in ("{c}" AND ("sales" OR "marketing" OR "customer success"))',
        f'site:linkedin.com/in ("{c}" AND ("it" OR "systems" OR "network"))',
    ]

    # Departments / org units
    dept_terms = [
        "IT",
        "information technology",
        "HR",
        "human resources",
        "finance",
        "accounting",
        "legal",
        "compliance",
        "risk",
        "operations",
        "customer support",
        "technical support",
        "training",
        "education",
        "clinical operations",
    ]
    dept_dorks = [
        f'site:linkedin.com/in ("{c}" AND "{dept}")' for dept in dept_terms
    ]

    # Format / snippet-based leaks (NO explicit 'works at' / 'current')
    # LinkedIn often uses " · {company}" in public snippets
    format_dorks = [
        f'site:linkedin.com/in "· {c}"',
        f'site:linkedin.com/in ("{c}" AND "·")',
        f'site:linkedin.com/in ("{c}" AND "title")',
        f'site:linkedin.com/in ("{c}" AND "company")',
    ]

    # Location / geo biased (generic but helpful)
    geo_terms = [
        "United States",
        "USA",
        "US",
        "North America",
        "Europe",
        "EMEA",
        "APAC",
        "remote",
    ]
    geo_dorks = [
        f'site:linkedin.com/in ("{c}" AND "{geo}")' for geo in geo_terms
    ]

    # People-search / semantics
    semantic_dorks = [
        f'site:linkedin.com/in ("{c}" AND "experience")',
        f'site:linkedin.com/in ("{c}" AND "skills")',
        f'site:linkedin.com/in ("{c}" AND "summary")',
        f'site:linkedin.com/in ("{c}" AND "linkedin profile")',
        f'site:linkedin.com/in ("{c}" AND "professional profile")',
    ]

    # Combine and deduplicate
    all_dorks = (
        base
        + seniority_dorks
        + role_dorks
        + or_role_dorks
        + dept_dorks
        + format_dorks
        + geo_dorks
        + semantic_dorks
    )

    # Deduplicate while preserving order
    seen = set()
    ordered = []
    for d in all_dorks:
        if d not in seen:
            seen.add(d)
            ordered.append(d)

    return ordered


# ================================
# SEARCH FUNCTION (HTML)
# ================================
def search_searx_html(query: str, start: int) -> str | None:
    """Send query to SearXNG and return raw HTML."""
    headers = {
        "User-Agent": random.choice(USER_AGENTS),
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    }

    try:
        resp = requests.get(
            f"{SEARX_INSTANCE}/search",
            params={
                "q": query,
                "language": "en",
                "safesearch": 0,
                "start": start,
            },
            headers=headers,
            timeout=REQUEST_TIMEOUT,
        )
        if resp.status_code == 403:
            print(f"{RED}[!] 403 Forbidden from SearXNG at start={start}{RESET}")
            return None
        resp.raise_for_status()
        return resp.text

    except Exception as e:
        print(f"{RED}[ERROR]{RESET} Request failed: {e}")
        return None


# ================================
# UNIVERSAL SNIPPET EXTRACTION
# ================================
def extract_profiles_with_snippets(
    html: str, company: str
) -> dict[str, str]:
    """
    Extract LinkedIn profile URLs and associated snippets (best-effort)
    from SearXNG HTML. Universal mode: works across multiple layouts.
    Returns: {profile_url: snippet_text}
    """
    soup = BeautifulSoup(html, "html.parser")
    results: dict[str, str] = {}

    # Look at all links and see which ones are LinkedIn profiles
    for a in soup.find_all("a", href=True):
        href = a["href"]
        matches = PROFILE_REGEX.findall(href)
        if not matches:
            continue

        for m in matches:
            clean = m.split("?")[0].rstrip("/")

            # Try to find a "result container" around this link
            container = a
            for _ in range(4):  # walk up a few levels max
                if not container:
                    break
                classes = (
                    " ".join(container.get("class", []))
                    if container.has_attr("class")
                    else ""
                )
                if "result" in classes or container.name in ("article", "li", "div"):
                    break
                container = container.parent

            snippet_text = ""

            if container:
                # Try known snippet-like classes first
                snippet_candidate = container.find(
                    class_=(
                        lambda c: c
                        and any(
                            tok in c
                            for tok in ["snippet", "content", "result-content", "result-snippet"]
                        )
                    )
                )
                if snippet_candidate:
                    snippet_text = snippet_candidate.get_text(" ", strip=True)
                else:
                    # Fallback: all <p> tags inside container
                    ps = container.find_all("p")
                    if ps:
                        snippet_text = " ".join(
                            p.get_text(" ", strip=True) for p in ps
                        )

            snippet_text = snippet_text or ""

            # Keep the snippet that looks most relevant/longest
            if clean not in results:
                results[clean] = snippet_text
            else:
                old = results[clean]
                if company.lower() in snippet_text.lower() and company.lower() not in old.lower():
                    results[clean] = snippet_text
                elif len(snippet_text) > len(old):
                    results[clean] = snippet_text

    return results


# ================================
# CURRENT EMPLOYEE SOFT FILTER
# ================================
def is_likely_current_employee(snippet: str, company: str) -> bool:
    """
    Soft filter for current employees:
    - Exclude if snippet clearly indicates a past role
    - Otherwise keep (even if ambiguous)
    """
    s = snippet.lower()

    past_terms = [
        "former ",
        "former-",
        "past ",
        "worked at",
        "previous ",
        "previously ",
        "ex-",
        "ex ",
        "alumni",
        "alumnus",
        "alumna",
    ]
    for term in past_terms:
        if term in s:
            return False

    return True


# ================================
# MAIN ENUMERATION
# ================================
def enumerate_employees(
    company: str, pagination_limit: int, current_only: bool
):
    print(f"\n{CYAN}[+] Enumerating employees for:{RESET} {company}")
    print(f"{CYAN}[+] Pagination depth:{RESET} 0 → {pagination_limit}")
    print(
        f"{CYAN}[+] Current employees only filter:{RESET} "
        f"{'ON' if current_only else 'OFF'}\n"
    )

    dorks = build_dorks(company)
    total_dorks = len(dorks)
    print(f"{CYAN}[+] Loaded {total_dorks} OSINT dorks in FULL mode.{RESET}\n")

    all_profiles: dict[str, str] = {}  # url -> snippet
    failed: list[tuple[str, int]] = []
    filtered_out = 0
    dork_hits: dict[str, int] = {}

    pagination_steps = list(range(0, pagination_limit + 1, 10))

    for idx, dork in enumerate(dorks, start=1):
        print(f"\n{CYAN}[*] Dork {idx}/{total_dorks}:{RESET} {dork}")

        dork_new_count = 0

        for start in pagination_steps:
            print(f"{CYAN}    → Page start={start}{RESET}")

            html = search_searx_html(dork, start)
            if not html:
                print(f"{RED}    [!] No HTML from SearXNG for this page{RESET}")
                failed.append((dork, start))
                continue

            profiles_with_snippets = extract_profiles_with_snippets(html, company)
            if not profiles_with_snippets:
                print(f"{RED}    [-] No profiles on this page{RESET}")
                time.sleep(random.uniform(1.0, 2.5))
                continue

            added_this_page = 0
            for url, snippet in profiles_with_snippets.items():
                if current_only and not is_likely_current_employee(snippet, company):
                    filtered_out += 1
                    continue

                if url not in all_profiles:
                    added_this_page += 1
                all_profiles[url] = snippet

            dork_new_count += added_this_page

            if added_this_page > 0:
                print(
                    f"{GREEN}    [+] {added_this_page} new profiles added from this page{RESET}"
                )
            else:
                print(f"{RED}    [-] No new profiles added from this page{RESET}")

            time.sleep(random.uniform(1.0, 2.5))  # jitter delay

        dork_hits[dork] = dork_new_count

    profiles_sorted = sorted(all_profiles.keys())
    return profiles_sorted, failed, filtered_out, dork_hits


# ================================
# SAVE RESULTS
# ================================
def save_results(company: str, profiles: list[str]):
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    folder = f"results_{company.replace(' ', '_')}"
    os.makedirs(folder, exist_ok=True)

    csv_path = os.path.join(folder, f"profiles_{timestamp}.csv")
    json_path = os.path.join(folder, f"profiles_{timestamp}.json")

    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["LinkedIn URL"])
        for p in profiles:
            writer.writerow([p])

    with open(json_path, "w", encoding="utf-8") as f:
        json.dump({"profiles": profiles}, f, indent=2)

    print(f"{GREEN}[+] Saved CSV →{RESET} {csv_path}")
    print(f"{GREEN}[+] Saved JSON →{RESET} {json_path}")


# ================================
# REPORT TOP DORKS
# ================================
def print_top_dorks(dork_hits: dict[str, int], top_n: int = 10):
    print(f"\n{CYAN}=== TOP {top_n} DORKS BY NEW PROFILES FOUND ==={RESET}")
    if not dork_hits:
        print(f"{RED}[!] No dork stats collected.{RESET}")
        return

    sorted_hits = sorted(
        dork_hits.items(), key=lambda kv: kv[1], reverse=True
    )
    for dork, count in sorted_hits[:top_n]:
        print(f"{GREEN}{count:4d}{RESET}  {dork}")


# ================================
# ENTRY POINT
# ================================
def main():
    print(
        "\n=== LinkedIn Employee Enumerator v4 "
        "(HTML + FULL Dorks + Pagination + Current Filter) ===\n"
    )
    company = input("Enter company name: ").strip()
    if not company:
        print(f"{RED}[!] Company name cannot be empty.{RESET}")
        return

    try:
        pagination_limit = int(
            input(
                CYAN
                + "Enter pagination depth (e.g., 50, 100, 150): "
                + RESET
            )
        )
        if pagination_limit < 0:
            raise ValueError
    except Exception:
        print(f"{RED}[!] Invalid pagination number.{RESET}")
        return

    current_choice = input(
        CYAN + "Filter for current employees only? (y/n): " + RESET
    ).strip().lower()
    current_only = current_choice == "y"

    profiles, failed, filtered_out, dork_hits = enumerate_employees(
        company, pagination_limit, current_only
    )

    print(f"\n{CYAN}=== FINAL RESULTS ==={RESET}")
    print(f"{GREEN}Found {len(profiles)} unique profiles after filtering{RESET}")
    if current_only:
        print(
            f"{CYAN}Profiles filtered out as likely past employees:{RESET} "
            f"{filtered_out}"
        )
    for p in profiles:
        print("  •", p)

    if failed:
        print(f"\n{RED}[!] Failed queries/pages:{RESET}")
        for d, s in failed:
            print(f"    - Dork: {d} | Page start={s}")

    print_top_dorks(dork_hits, top_n=10)

    if profiles:
        save_results(company, profiles)
    else:
        print(f"{RED}[!] No profiles to save.{RESET}")


if __name__ == "__main__":
    main()
