#!/usr/bin/env python3
import os
import sys
import importlib.util
import importlib.machinery
from pathlib import Path

# ============================
# CROWSNEST BLUE THEME COLORS
# ============================
BLUE      = "\033[38;5;39m"
BLUE_BOLD = "\033[1;38;5;39m"
CYAN      = "\033[36m"
WHITE     = "\033[97m"
GREY      = "\033[90m"
RESET     = "\033[0m"

# ============================
# ASCII BANNER
# ============================
BANNER = f"""
{BLUE_BOLD} ░███████   ░█████████  ░██████████ ░███████   ░███████   
{BLUE_BOLD} ░██   ░██  ░██     ░██ ░██         ░██   ░██  ░██   ░██  
{BLUE_BOLD} ░██    ░██ ░██     ░██ ░██         ░██    ░██ ░██    ░██ 
{BLUE_BOLD} ░██    ░██ ░█████████  ░█████████  ░██    ░██ ░██    ░██ 
{BLUE_BOLD} ░██    ░██ ░██   ░██   ░██         ░██    ░██ ░██    ░██ 
{BLUE_BOLD} ░██   ░██  ░██    ░██  ░██         ░██   ░██  ░██   ░██  
{BLUE_BOLD} ░███████   ░██     ░██ ░██████████ ░███████   ░███████  
{BLUE_BOLD}                                     
{CYAN}Data Reconnaissance, Enumeration and Digital Discovery suite
{RESET}
"""

# ============================================================
# MODULE AUTO-DETECTION
# ============================================================
def discover_modules(base_dir):
    modules = {}

    priority_keywords = [
        "main", "start", "run",
        "profile", "case",
        "enum", "linkedin",
        "crawl", "social",
        "checker", "ssl",
        "hash", "seek",
        "whois", "lookup"
    ]

    ignore_keywords = [
        "__init__", "utils", "helper", "engine", "alias", "webapp"
    ]

    for folder in sorted(os.listdir(base_dir)):
        full_path = base_dir / folder
        if not full_path.is_dir():
            continue

        py_files = [p for p in full_path.iterdir() if p.suffix == ".py"]
        if not py_files:
            continue

        filtered = [
            f for f in py_files
            if not any(k in f.name.lower() for k in ignore_keywords)
        ]
        candidates = filtered if filtered else py_files

        scored = []
        for f in candidates:
            score = sum(k in f.name.lower() for k in priority_keywords)
            scored.append((score, f))

        scored.sort(reverse=True, key=lambda x: x[0])
        best_file = scored[0][1]

        modules[folder] = {
            "folder": folder,
            "file": best_file.name,
            "path": best_file
        }

    return modules

# ============================================================
# CASE CREATION SUBMENU
# ============================================================
def handle_case_creation(module_info):
    script_path = module_info["path"]      # profile.py
    folder_path = script_path.parent       # CaseCreation1.0

    while True:
        os.system("clear")
        print(f"{BLUE_BOLD}Case Creation Module{RESET}")
        print(GREY + "────────────────────────────────────────────" + RESET)
        print(f"{CYAN}1{RESET}) Start New Case")
        print(f"{CYAN}2{RESET}) Open CaseCreation1.0 Folder")
        print(f"{CYAN}3{RESET}) Run Case Wizard")
        print(f"{CYAN}4{RESET}) Generate AI Prompt for Case")
        print(f"{CYAN}0{RESET}) Back\n")

        choice = input("Select option: ").strip()

        # Back to main launcher
        if choice == "0":
            return

        # 1) Start New Case
        if choice == "1":
            project = input("Enter project folder name: ").strip()
            if not project:
                input("Project name cannot be empty. Press Enter...")
                continue

            cmd = (
                f"cd '{folder_path}' && "
                f"python3 '{script_path.name}' init --project '{project}'"
            )
            os.system(cmd)
            input("\nPress Enter...")
            continue

        # 2) Open CaseCreation folder
        if choice == "2":
            os.system(f"xdg-open '{folder_path}'")
            input("\nPress Enter...")
            continue

        # 3) Run Wizard
        if choice == "3":
            project = input("Enter project name (leave blank for none): ").strip()

            if project:
                cmd = (
                    f"cd '{folder_path}' && "
                    f"python3 '{script_path.name}' wizard --project '{project}'"
                )
            else:
                cmd = (
                    f"cd '{folder_path}' && "
                    f"python3 '{script_path.name}' wizard"
                )

            os.system(cmd)
            input("\nPress Enter...")
            continue

        # ⭐ 4) Generate AI Prompt for Case
        if choice == "4":
            project = input("Enter the project/case name: ").strip()
            if not project:
                input("Project name cannot be empty. Press Enter...")
                continue

            # Call the AI prompt generator module
            ai_cmd = (
                f"cd '{folder_path}' && "
                f"python3 -m osint_ext.ai_cli prompt --project '{project}'"
            )

            print(f"{CYAN}\n[+] Generating AI prompt for project '{project}'...\n{RESET}")
            os.system(ai_cmd)

            input("\nPress Enter to continue...")
            continue

# ============================================================
# Hash and Seek SUBMENU
# ============================================================

def handle_hashandseek(module_info):
    file_path = module_info["path"]
    folder_path = file_path.parent

    while True:
        os.system("clear")
        print(f"{BLUE_BOLD}HashAndSeek Module{RESET}")
        print(GREY + "────────────────────────────────────────────" + RESET)
        print(f"{CYAN}1{RESET}) Calculate File Hash (SHA256/MD5)")
        print(f"{CYAN}2{RESET}) Search System for Matching Hash")
        print(f"{CYAN}0{RESET}) Back\n")

        choice = input("Select option: ").strip()

        if choice == "0":
            return

        # 1) Auto-hash mode
        if choice == "1":
            target = input("Enter file path: ").strip()
            if not target:
                input("Path cannot be empty. Press Enter...")
                continue

            algo = input("Hash algorithm (sha256/md5) [sha256]: ").strip().lower()
            if algo not in ("sha256", "md5", ""):
                input("Invalid algorithm. Press Enter...")
                continue

            if algo == "":
                algo = "sha256"

            cmd = (
                f"cd '{folder_path}' && "
                f"python3 '{file_path.name}' --auto-hash '{target}' --algo '{algo}'"
            )
            os.system(cmd)
            input("\nPress Enter to continue...")
            continue

        # 2) Auto-search mode
        if choice == "2":
            search_hash = input("Enter hash to search for: ").strip()
            if not search_hash:
                input("Hash cannot be empty. Press Enter...")
                continue

            start_dir = input(
                "Enter directory to search (leave blank for current): "
            ).strip()

            directory_arg = f"'{start_dir}'" if start_dir else "."

            cmd = (
                f"cd '{folder_path}' && "
                f"python3 '{file_path.name}' --auto-search '{search_hash}' --directory {directory_arg}"
            )
            os.system(cmd)
            input("\nPress Enter to continue...")
            continue


# ============================================================
# SSL CHECKER SUBMENU
# ============================================================
def handle_sslchecker(module_info):
    script_path = module_info["path"]
    folder_path = script_path.parent

    while True:
        os.system("clear")
        print(f"{BLUE_BOLD}SSL Checker Module{RESET}")
        print(GREY + "────────────────────────────────────────────" + RESET)
        print(f"{CYAN}1{RESET}) Run SSL Check")
        print(f"{CYAN}0{RESET}) Back\n")

        c = input("Enter option: ")

        if c == "0":
            return

        if c == "1":
            host = input("Enter hostname: ").strip()
            if host:
                os.system(f"cd '{folder_path}' && python3 '{script_path.name}' '{host}'")
            input("\nPress Enter...")
            continue

# ============================================================
# SOCIAL CRAWL SUBMENU
# ============================================================
def handle_socialcrawl(module_info):
    script_path = module_info["path"]
    folder_path = script_path.parent

    while True:
        os.system("clear")
        print(f"{BLUE_BOLD}SocialCrawl Module{RESET}")
        print(GREY + "────────────────────────────────────────────" + RESET)
        print(f"{CYAN}1{RESET}) Run SocialCrawl")
        print(f"{CYAN}0{RESET}) Back\n")

        c = input("Select option: ")

        if c == "0":
            return

        if c == "1":
            username = input("Enter username: ").strip()
            aliases_opt = input("Include aliases? (y/N): ").strip().lower()
            html_opt    = input("Generate HTML report? (y/N): ").strip().lower()
            stealth_opt = input("Enable stealth mode? (y/N): ").strip().lower()

            flags = [
                f"--username '{username}'",
                "--sites-json sites.json"
            ]
            if aliases_opt.startswith("y"):
                flags.append("--aliases")
            if html_opt.startswith("y"):
                flags.append("--html-report")
            if stealth_opt.startswith("y"):
                flags.append("--stealth")

            cmd = f"cd '{folder_path}' && python3 '{script_path.name}' " + " ".join(flags)
            os.system(cmd)
            input("\nPress Enter...")

# ============================================================
# WHOIS LOOKUP SUBMENU
# ============================================================
def handle_whoislookup(module_info):
    script_path = module_info["path"]
    folder_path = script_path.parent

    while True:
        os.system("clear")
        print(f"{BLUE_BOLD}Whois Lookup Module{RESET}")
        print(GREY + "────────────────────────────────────────────" + RESET)
        print(f"{CYAN}1{RESET}) Lookup Domain")
        print(f"{CYAN}2{RESET}) Lookup IP Address")
        print(f"{CYAN}0{RESET}) Back\n")

        c = input("Select option: ")

        if c == "0":
            return

        if c == "1":
            target = input("Enter domain (example.com): ").strip()
            os.system(f"cd '{folder_path}' && python3 '{script_path.name}' '{target}'")
            input("\nPress Enter...")
            continue

        if c == "2":
            target = input("Enter IP: ").strip()
            os.system(f"cd '{folder_path}' && python3 '{script_path.name}' '{target}'")
            input("\nPress Enter...")
            continue

# ============================================================
# UNIVERSAL MODULE EXECUTION HANDLER
# ============================================================
def run_module(module_info):
    folder = module_info["folder"]
    fl = folder.lower()

    if fl.startswith("casecreation"):
        handle_case_creation(module_info)
        return

    if fl.startswith("hashandseek"):
        handle_hashandseek(module_info)
        return

    if fl.startswith("sslchecker"):
        handle_sslchecker(module_info)
        return

    if fl.startswith("socialcrawl"):
        handle_socialcrawl(module_info)
        return

    if fl.startswith("whoislookup"):
        handle_whoislookup(module_info)
        return

    print(f"{CYAN}[+] Launching module: {folder}{RESET}")
    os.system(f"cd '{module_info['path'].parent}' && python3 '{module_info['file']}'")
    input("\nPress Enter...")

# ============================================================
# MENU DISPLAY
# ============================================================
def show_menu(modules):
    os.system("clear")
    print(BANNER)

    print(f"{WHITE}Detected Modules:{RESET}")
    print(GREY + "────────────────────────────────────────────" + RESET)

    for i, folder in enumerate(modules.keys(), 1):
        print(f"{CYAN}{i:02d}{RESET}  {WHITE}{folder}{RESET}")

    print(GREY + "────────────────────────────────────────────" + RESET)
    print(f"{CYAN}00{RESET}  Exit\n")

# ============================================================
# MAIN LOOP
# ============================================================
def main():
    base_dir = Path(__file__).resolve().parent
    sys.path.insert(0, str(base_dir))

    modules = discover_modules(base_dir)
    if not modules:
        print("[!] No modules found.")
        return

    while True:
        show_menu(modules)
        choice = input(f"{BLUE_BOLD}Select Module: {RESET}")

        if choice in ("0", "00"):
            print(f"{CYAN}Goodbye!{RESET}")
            sys.exit()

        try:
            idx = int(choice) - 1
            folder_key = list(modules.keys())[idx]
        except:
            continue

        run_module(modules[folder_key])


if __name__ == "__main__":
    main()
