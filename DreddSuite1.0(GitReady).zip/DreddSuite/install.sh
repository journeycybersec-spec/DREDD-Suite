#!/usr/bin/env bash

echo ""
echo "========================================="
echo "   DreddSuite Installer (Linux/macOS)"
echo "========================================="
echo ""

# ------------------------------
# 1. Check Python version
# ------------------------------
if ! command -v python3 >/dev/null 2>&1; then
    echo "ERROR: python3 is not installed."
    exit 1
fi

PY_VERSION=$(python3 -c "import sys; print(sys.version_info.major)")
if [ "$PY_VERSION" -ne 3 ]; then
    echo "ERROR: Python 3 is required."
    exit 1
fi

echo "[+] Python version OK"

# ------------------------------
# 2. Create virtual environment
# ------------------------------
echo "[+] Creating virtual environment: venv/"
python3 -m venv venv || {
    echo "ERROR: Failed to create venv"
    exit 1
}

# ------------------------------
# 3. Activate environment
# ------------------------------
echo "[+] Activating virtual environment"
source venv/bin/activate

# ------------------------------
# 4. Upgrade pip
# ------------------------------
echo "[+] Upgrading pip"
pip install --upgrade pip

# ------------------------------
# 5. Install requirements
# ------------------------------
if [ ! -f "requirements.txt" ]; then
    echo "ERROR: requirements.txt not found!"
    exit 1
fi

echo "[+] Installing required Python packages..."
pip install -r requirements.txt || {
    echo "ERROR installing Python packages"
    exit 1
}

# ------------------------------
# 6. Create launch script
# ------------------------------
echo "[+] Creating run_dreddsuite.sh launcher"

cat << 'EOF' > run_dreddsuite.sh
#!/usr/bin/env bash
source venv/bin/activate
python3 DreddSuiteLauncher.py
EOF

chmod +x run_dreddsuite.sh

# ------------------------------
# 7. Optional: Desktop launcher
# ------------------------------
if [[ "$1" == "--desktop" ]]; then
    echo "[+] Creating desktop icon"

    cat << EOF > "$HOME/Desktop/DreddSuite.desktop"
[Desktop Entry]
Type=Application
Name=DreddSuite
Exec=$(pwd)/run_dreddsuite.sh
Icon=utilities-terminal
Terminal=true
EOF

    chmod +x "$HOME/Desktop/DreddSuite.desktop"
    echo "[+] Desktop launcher created!"
fi

echo ""
echo "========================================="
echo " DreddSuite Installation Completed ✔"
echo " To launch, run: ./run_dreddsuite.sh"
echo "========================================="
echo ""
