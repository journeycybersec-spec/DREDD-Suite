# file: profile.py
#!/usr/bin/env python3
"""
OSINT Company Profile CLI (profile.py)
- Two modes:
    * collect : classic prompts (comma-separated)
    * wizard  : guided UI (colors, progress, autosave)
- Sections A..G modeled via dataclasses
- Exports: JSON + Python vars
- HTML reporting
- Rotating logs, debug mode
- Plugin handoff (module:function)
"""

from __future__ import annotations
import argparse
import json
import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path
from dataclasses import dataclass, field, asdict
from typing import List, Optional, Dict, Any, Callable, Tuple
import sys
import datetime
from datetime import timezone
import traceback
import ipaddress
import importlib
import html
from html import escape as html_escape
import webbrowser

# --------------------------- Time ------------------------------------

def utc_now_z() -> str:
    """Timezone-aware UTC timestamp in ISO-8601 with trailing Z."""
    return datetime.datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

# --------------------------- Logging ---------------------------------

def setup_logging(base_dir: Path, debug: bool) -> Path:
    base_dir.mkdir(parents=True, exist_ok=True)
    log_dir = base_dir / "logs"
    log_dir.mkdir(exist_ok=True)
    log_path = log_dir / "app.log"

    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG if debug else logging.INFO)
    logger.handlers.clear()

    fhandler = RotatingFileHandler(log_path, maxBytes=512_000, backupCount=3)
    fhandler.setLevel(logging.DEBUG)
    fhandler.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(name)s | %(message)s"))
    logger.addHandler(fhandler)

    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(logging.DEBUG if debug else logging.INFO)
    ch.setFormatter(logging.Formatter("%(levelname)s: %(message)s"))
    logger.addHandler(ch)

    logging.debug("Logging initialized.")
    return log_path

def log_exceptions(func: Callable[..., Any]) -> Callable[..., Any]:
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except KeyboardInterrupt:
            logging.warning("Interrupted by user.")
            sys.exit(130)
        except Exception as ex:
            logging.error("Unhandled error: %s", ex)
            logging.debug("Traceback:\n%s", traceback.format_exc())
            print(f"ERROR: {ex}")
            sys.exit(1)
    return wrapper

# --------------------------- Models ----------------------------------

@dataclass
class CompanyIdentity:
    legal_business_name: str = ""
    alternate_names_dbas: List[str] = field(default_factory=list)
    parent_company: str = ""
    subsidiaries_brands: List[str] = field(default_factory=list)
    registered_business_number: str = ""
    corporate_registration_id: str = ""   # jurisdiction-specific
    industry_naics_sic: List[str] = field(default_factory=list)

@dataclass
class DomainsFootprint:
    primary_domain: str = ""
    secondary_domains: List[str] = field(default_factory=list)
    parked_domains: List[str] = field(default_factory=list)
    tld_variants: List[str] = field(default_factory=list)
    known_ips: List[str] = field(default_factory=list)
    hosting_provider: str = ""
    ssl_issuer: str = ""
    typosquatting_variants: List[str] = field(default_factory=list)

@dataclass
class AddressesContacts:
    registered_legal_address: str = ""
    operating_address: str = ""
    mailing_address: str = ""
    customer_support_emails: List[str] = field(default_factory=list)
    sales_emails: List[str] = field(default_factory=list)
    support_phone_number: str = ""
    corporate_phone_number: str = ""

@dataclass
class KeyPeople:
    executives: List[str] = field(default_factory=list)
    founders: List[str] = field(default_factory=list)
    board_members: List[str] = field(default_factory=list)
    corporate_officers: List[str] = field(default_factory=list)
    security_it_leaders: List[str] = field(default_factory=list)
    public_facing_employees: List[str] = field(default_factory=list)

@dataclass
class PlatformsPresence:
    linkedin: str = ""
    twitter_x: str = ""
    facebook: str = ""
    instagram: str = ""
    youtube: str = ""
    github_org: str = ""
    product_pages: List[str] = field(default_factory=list)
    api_endpoints: List[str] = field(default_factory=list)
    mobile_apps_android: List[str] = field(default_factory=list)
    mobile_apps_ios: List[str] = field(default_factory=list)

@dataclass
class FinancialFootprint:
    investors: List[str] = field(default_factory=list)
    funding_rounds: List[str] = field(default_factory=list)
    payment_processors: List[str] = field(default_factory=list)
    banking_partners: List[str] = field(default_factory=list)

@dataclass
class SecurityContext:
    regulated_industry: str = ""   # yes/no/unknown + details
    known_breaches: List[str] = field(default_factory=list)
    news_references: List[str] = field(default_factory=list)
    known_phishing_domains: List[str] = field(default_factory=list)

@dataclass
class CompanyProfile:
    identity: CompanyIdentity = field(default_factory=CompanyIdentity)
    domains: DomainsFootprint = field(default_factory=DomainsFootprint)
    contacts: AddressesContacts = field(default_factory=AddressesContacts)
    people: KeyPeople = field(default_factory=KeyPeople)
    platforms: PlatformsPresence = field(default_factory=PlatformsPresence)
    financial: FinancialFootprint = field(default_factory=FinancialFootprint)
    security: SecurityContext = field(default_factory=SecurityContext)
    created_at: str = field(default_factory=utc_now_z)
    updated_at: str = field(default_factory=utc_now_z)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @staticmethod
    def from_dict(d: Dict[str, Any]) -> "CompanyProfile":
        def _sub(cls, key):
            return cls(**d.get(key, {}))
        return CompanyProfile(
            identity=_sub(CompanyIdentity, "identity"),
            domains=_sub(DomainsFootprint, "domains"),
            contacts=_sub(AddressesContacts, "contacts"),
            people=_sub(KeyPeople, "people"),
            platforms=_sub(PlatformsPresence, "platforms"),
            financial=_sub(FinancialFootprint, "financial"),
            security=_sub(SecurityContext, "security"),
            created_at=d.get("created_at", utc_now_z()),
            updated_at=d.get("updated_at", utc_now_z()),
        )

    def touch(self) -> None:
        self.updated_at = utc_now_z()

# --------------------------- Storage ---------------------------------

def load_profile(path: Path) -> CompanyProfile:
    if not path.exists():
        logging.info("Profile not found at %s. Creating a new blank profile.", path)
        return CompanyProfile()
    with path.open("r", encoding="utf-8") as f:
        data = json.load(f)
    logging.debug("Profile loaded from %s", path)
    return CompanyProfile.from_dict(data)

def save_profile(profile: CompanyProfile, path: Path, pretty: bool = True) -> None:
    profile.touch()
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        if pretty:
            json.dump(profile.to_dict(), f, indent=2, ensure_ascii=False)
        else:
            json.dump(profile.to_dict(), f, separators=(",", ":"), ensure_ascii=False)
    logging.info("Profile saved to %s", path)

def export_python_vars(profile: CompanyProfile, out_path: Path) -> None:
    """Export a .py file with module-level variables for direct import."""
    out_path.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(profile.to_dict(), indent=2, ensure_ascii=False)
    code = f'''# Auto-generated OSINT company profile variables
# WARNING: Do not edit by hand. Regenerate via CLI.
PROFILE_JSON = r"""{payload}"""

import json
def get_profile_dict():
    return json.loads(PROFILE_JSON)

# convenience shortcuts:
PROFILE = get_profile_dict()
IDENTITY = PROFILE["identity"]
DOMAINS = PROFILE["domains"]
CONTACTS = PROFILE["contacts"]
PEOPLE = PROFILE["people"]
PLATFORMS = PROFILE["platforms"]
FINANCIAL = PROFILE["financial"]
SECURITY = PROFILE["security"]
'''
    out_path.write_text(code, encoding="utf-8")
    logging.info("Python variables exported to %s", out_path)

# --------------------------- UI Helpers ------------------------------

ANSI = {
    "reset": "\033[0m",
    "bold": "\033[1m",
    "dim": "\033[2m",
    "underline": "\033[4m",
    "cyan": "\033[36m",
    "yellow": "\033[33m",
    "green": "\033[32m",
    "magenta": "\033[35m",
    "red": "\033[31m",
    "blue": "\033[34m",
    "blue_bright": "\033[94m",
    "white_bright": "\033[97m",
}

def colorize(s: str, color: str, use_color: bool) -> str:
    if not use_color:
        return s
    return f"{ANSI.get(color,'')}{s}{ANSI['reset']}"

def underline_for(text: str) -> str:
    """Underline with unicode if UTF-8, else ASCII."""
    enc = (sys.stdout.encoding or "").upper()
    ch = "─" if "UTF-8" in enc else "-"
    return ch * len(text)

def ui_title(text: str, use_color: bool) -> None:
    pad = 2
    title = text.upper()
    line = " " * pad + title + " " * pad
    top = "╔" + ("═" * len(line)) + "╗"
    mid = "║" + line + "║"
    bot = "╚" + ("═" * len(line)) + "╝"
    print(colorize(top, "cyan", use_color))
    print(colorize(colorize(mid, "bold", use_color), "cyan", use_color))
    print(colorize(bot, "cyan", use_color))

def ui_section(title: str, subtitle: str, use_color: bool) -> None:
    """Boxed cyan section header with indented subtitle."""
    print()
    pad = 2
    line = " " * pad + title + " " * pad
    top = "╔" + ("═" * len(line)) + "╗"
    mid = "║" + line + "║"
    bot = "╚" + ("═" * len(line)) + "╝"
    print(colorize(top, "cyan", use_color))
    print(colorize(colorize(mid, "bold", use_color), "cyan", use_color))
    print(colorize(bot, "cyan", use_color))
    if subtitle:
        print(colorize(f"  └─ {subtitle}", "dim", use_color))

def ui_progress(done: int, total: int, use_color: bool) -> None:
    pct = int((done / total) * 100) if total else 0
    bar_len = 20
    filled = int(bar_len * pct / 100)
    bar = "[" + "#" * filled + "-" * (bar_len - filled) + f"] {pct}%"
    line = f"Progress: {bar}"
    print(colorize(line, "cyan", use_color))

def yes_no(prompt_text: str, default_yes: bool, use_color: bool) -> bool:
    suffix = "Y/n" if default_yes else "y/N"
    while True:
        ans = input(colorize(f"{prompt_text} ({suffix}): ", "yellow", use_color)).strip().lower()
        if not ans:
            return default_yes
        if ans in ("y","yes"): return True
        if ans in ("n","no"): return False
        print(colorize("Please enter y or n.", "red", use_color))


# --------------------------- Input Helpers ---------------------------

def prompt(text_: str, default: Optional[str] = None) -> str:
    try:
        raw = input(f"{text_}" + (f" [{default}]" if default else "") + ": ").strip()
    except EOFError:
        raw = ""
    return raw if raw else (default or "")

def prompt_list(text_: str, default: Optional[List[str]] = None) -> List[str]:
    default_str = ", ".join(default) if default else ""
    s = prompt(f"{text_} (comma-separated)", default_str)
    items = [i.strip() for i in s.split(",") if i.strip()] if s else []
    return items

def prompt_multiline(text_: str, default: Optional[str] = None) -> str:
    """
    Multiline input helper.
    Finish on an empty line (preferred) or a single '.'.
    If no new lines are entered and a default exists, keeps the default.
    """
    if text_:
        print(f"{text_} (finish with an empty line; '.' also supported)")
    lines: List[str] = []
    if default:
        print("[press ENTER on an empty line to keep default]")
        print(default)
        print("---")
    while True:
        try:
            line = input()
        except EOFError:
            break
        if line.strip() == ".":
            break
        if line == "":
            if not lines and default is not None:
                return default
            break
        lines.append(line)
    return "\n".join(lines).strip()

# ------------------------ Classic Collectors --------------------------

def collect_identity(identity: CompanyIdentity) -> CompanyIdentity:
    identity.legal_business_name = prompt("Legal business name", identity.legal_business_name)
    identity.alternate_names_dbas = prompt_list("Alternate names / DBAs", identity.alternate_names_dbas)
    identity.parent_company = prompt("Parent company", identity.parent_company)
    identity.subsidiaries_brands = prompt_list("Subsidiaries / brands", identity.subsidiaries_brands)
    identity.registered_business_number = prompt("Registered business number", identity.registered_business_number)
    identity.corporate_registration_id = prompt("Corporate registration ID (jurisdiction-specific)", identity.corporate_registration_id)
    identity.industry_naics_sic = prompt_list("Industry codes (NAICS/SIC)", identity.industry_naics_sic)
    return identity

def collect_domains(domains: DomainsFootprint) -> DomainsFootprint:
    domains.primary_domain = prompt("Primary domain", domains.primary_domain).lower()
    domains.secondary_domains = clean_domains(prompt_list("Secondary domains", domains.secondary_domains))
    domains.parked_domains = clean_domains(prompt_list("Parked domains", domains.parked_domains))
    domains.tld_variants = clean_domains(prompt_list("All TLD variants", domains.tld_variants))
    domains.known_ips = clean_ips(prompt_list("Known IPs", domains.known_ips))
    domains.hosting_provider = prompt("Hosting provider", domains.hosting_provider)
    domains.ssl_issuer = prompt("SSL issuer", domains.ssl_issuer)
    if domains.primary_domain:
        auto_typos = gen_typosquats(domains.primary_domain, limit=50)
        current = set(domains.typosquatting_variants)
        domains.typosquatting_variants = sorted(current.union(auto_typos))
    domains.typosquatting_variants = clean_domains(
        prompt_list("Typosquatting variants (edit/add)", domains.typosquatting_variants)
    )
    return domains

def collect_contacts(contacts: AddressesContacts) -> AddressesContacts:
    print("Registered legal address"); contacts.registered_legal_address = prompt_multiline("", contacts.registered_legal_address)
    print("Operating address");        contacts.operating_address       = prompt_multiline("", contacts.operating_address)
    print("Mailing address");          contacts.mailing_address         = prompt_multiline("", contacts.mailing_address)
    contacts.customer_support_emails = prompt_list("Customer support email(s)", contacts.customer_support_emails)
    contacts.sales_emails = prompt_list("Sales email(s)", contacts.sales_emails)
    contacts.support_phone_number = prompt("Support phone number", contacts.support_phone_number)
    contacts.corporate_phone_number = prompt("Corporate phone number", contacts.corporate_phone_number)
    return contacts

def collect_people(people: KeyPeople) -> KeyPeople:
    people.executives = prompt_list("Executives", people.executives)
    people.founders = prompt_list("Founders", people.founders)
    people.board_members = prompt_list("Board members", people.board_members)
    people.corporate_officers = prompt_list("Corporate officers", people.corporate_officers)
    people.security_it_leaders = prompt_list("Security/IT leaders", people.security_it_leaders)
    people.public_facing_employees = prompt_list("Public-facing employees (if any)", people.public_facing_employees)
    return people

def collect_platforms(platforms: PlatformsPresence) -> PlatformsPresence:
    platforms.linkedin = prompt("Official LinkedIn page", platforms.linkedin)
    platforms.twitter_x = prompt("Official Twitter/X", platforms.twitter_x)
    platforms.facebook = prompt("Facebook", platforms.facebook)
    platforms.instagram = prompt("Instagram", platforms.instagram)
    platforms.youtube = prompt("YouTube", platforms.youtube)
    platforms.github_org = prompt("GitHub org", platforms.github_org)
    platforms.product_pages = prompt_list("Product pages (URLs)", platforms.product_pages)
    platforms.api_endpoints = prompt_list("API endpoints (base URLs)", platforms.api_endpoints)
    platforms.mobile_apps_android = prompt_list("Mobile apps (Android)", platforms.mobile_apps_android)
    platforms.mobile_apps_ios = prompt_list("Mobile apps (iOS)", platforms.mobile_apps_ios)
    return platforms

def collect_financial(fin: FinancialFootprint) -> FinancialFootprint:
    fin.investors = prompt_list("Investors", fin.investors)
    fin.funding_rounds = prompt_list("Funding rounds (brief notes)", fin.funding_rounds)
    fin.payment_processors = prompt_list("Payment processors", fin.payment_processors)
    fin.banking_partners = prompt_list("Banking partners (if disclosed)", fin.banking_partners)
    return fin

def collect_security(sec: SecurityContext) -> SecurityContext:
    sec.regulated_industry = prompt("Regulated industry? (yes/no/unknown + details)", sec.regulated_industry)
    sec.known_breaches = prompt_list("Known breaches (notes/links)", sec.known_breaches)
    sec.news_references = prompt_list("News references (URLs/titles)", sec.news_references)
    sec.known_phishing_domains = clean_domains(prompt_list("Known phishing domains", sec.known_phishing_domains))
    return sec

# --------------------------- Validators & Utils -----------------------

def valid_domain(s: str) -> bool:
    return "." in s and " " not in s and s == s.lower()

def valid_ip(s: str) -> bool:
    try:
        ipaddress.ip_address(s)
        return True
    except Exception:
        return False

def clean_domains(domains: List[str]) -> List[str]:
    out = []
    for d in domains:
        d2 = d.strip().lower()
        if d2 and valid_domain(d2):
            out.append(d2)
        else:
            if d2:
                logging.debug("Skipping invalid domain: %s", d)
    return sorted(set(out))

def clean_ips(ips: List[str]) -> List[str]:
    out = []
    for ip in ips:
        ip2 = ip.strip()
        if not ip2:
            continue
        if valid_ip(ip2):
            out.append(ip2)
        else:
            logging.debug("Skipping invalid IP: %s", ip)
    return sorted(set(out))

def gen_typosquats(domain: str, limit: int = 50) -> List[str]:
    """Small, deterministic candidates for later searching."""
    try:
        name, tld = domain.rsplit(".", 1)
    except ValueError:
        return []
    variants = set()
    # omission
    for i in range(len(name)):
        variants.add(name[:i] + name[i+1:] + "." + tld)
    # transpose
    for i in range(len(name) - 1):
        swapped = list(name)
        swapped[i], swapped[i+1] = swapped[i+1], swapped[i]
        variants.add("".join(swapped) + "." + tld)
    # vowel replacement
    for i, ch in enumerate(name):
        for r in "aeiou":
            if ch != r:
                variants.add(name[:i] + r + name[i+1:] + "." + tld)
    # common TLD flips
    tld_alts = {"com", "co", "net", "org", "io", "ai", "co.uk"}
    for alt in tld_alts:
        if alt != tld:
            variants.add(f"{name}.{alt}")
    out = [v for v in variants if valid_domain(v) and v != domain]
    out.sort()
    return out[:limit]

# Wizard-specific iterative list input with validation and controls
def prompt_list_iterative(
    label: str,
    field_number: int,
    existing: List[str],
    validator: Optional[Callable[[str], bool]],
    hint: str,
    use_color: bool
) -> List[str]:
    print(colorize(f"\n[{field_number}] {label}", "cyan", use_color))
    print(colorize(f"     └─ Hint: {hint}", "dim", use_color))
    print(colorize("     └─ Enter one per line. Empty line = finish. Type 'list' to show current; 'del <n>' to delete.", "dim", use_color))
    items = list(existing)
    while True:
        raw = input(colorize("     > ", "yellow", use_color)).strip()
        if raw == "":
            break
        if raw.lower() == "list":
            if not items:
                print(colorize("       (empty)", "dim", use_color))
            else:
                for i, v in enumerate(items, 1):
                    print(colorize(f"       {i}. {v}", "dim", use_color))
            continue
        if raw.lower().startswith("del "):
            try:
                idx = int(raw.split()[1]) - 1
                if 0 <= idx < len(items):
                    removed = items.pop(idx)
                    print(colorize(f"       ✖ removed: {removed}", "red", use_color))
                else:
                    print(colorize("       invalid index.", "red", use_color))
            except Exception:
                print(colorize("       usage: del <n>", "red", use_color))
            continue
        if validator and not validator(raw):
            print(colorize("       ✖ invalid value; try again.", "red", use_color))
            continue
        items.append(raw)
        print(colorize("       ✓ added.", "green", use_color))
    return items

# --------------------------- HTML Report ------------------------------

def render_html_report(profile: CompanyProfile) -> str:
    p = profile.to_dict()

    def ul(items: List[str]) -> str:
        if not items:
            return "<em>None</em>"
        return "<ul>" + "".join(f"<li>{html_escape(i)}</li>" for i in items) + "</ul>"

    def pre(s: str) -> str:
        if not s:
            return "<em>None</em>"
        return f"<pre>{html_escape(s)}</pre>"

    def maybe(s: str) -> str:
        return html_escape(s) if s else "<em>None</em>"

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Company OSINT Profile</title>

<style>
  :root {{
    --bg: #ffffff;
    --fg: #0f172a;          /* slate-900 */
    --muted: #475569;       /* slate-600 */
    --card: #ffffff;
    --border: #e5e7eb;      /* gray-200 */
    --accent: #0b5fe0;      /* blue */
    --accent-weak: #dbeafe; /* blue-100 */
    --code-bg: #f6f8fa;
    --shadow: 0 1px 2px rgba(0,0,0,.06), 0 4px 10px rgba(0,0,0,.04);
  }}

  @media (prefers-color-scheme: dark) {{
    :root {{
      --bg: #0b1220;
      --fg: #e5e7eb;
      --muted: #94a3b8;
      --card: #0f172a;
      --border: #1f2937;
      --accent: #60a5fa;
      --accent-weak: #1e293b;
      --code-bg: #0b1220;
      --shadow: none;
    }}
  }}

  [data-theme="light"] {{
    --bg: #ffffff;
    --fg: #0f172a;
    --muted: #475569;
    --card: #ffffff;
    --border: #e5e7eb;
    --accent: #0b5fe0;
    --accent-weak: #dbeafe;
    --code-bg: #f6f8fa;
    --shadow: 0 1px 2px rgba(0,0,0,.06), 0 4px 10px rgba(0,0,0,.04);
  }}
  [data-theme="dark"] {{
    --bg: #0b1220;
    --fg: #e5e7eb;
    --muted: #94a3b8;
    --card: #0f172a;
    --border: #1f2937;
    --accent: #60a5fa;
    --accent-weak: #1e293b;
    --code-bg: #0b1220;
    --shadow: none;
  }}

  html, body {{ height: 100%; }}
  body {{
    margin: 0;
    background: var(--bg);
    color: var(--fg);
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    line-height: 1.6;
  }}
  .container {{
    max-width: 960px;
    margin: 0 auto;
    padding: 2rem;
  }}
  header {{
    text-align: center;
    padding: 2rem 0;
    border-bottom: 2px solid var(--border);
    margin-bottom: 2rem;
  }}
  h1 {{
    margin: 0 0 0.5rem;
    font-size: 2.5rem;
    color: var(--accent);
  }}
  .subtitle {{
    color: var(--muted);
    font-size: 0.95rem;
  }}
  section {{
    background: var(--card);
    padding: 1.5rem;
    margin-bottom: 2rem;
    border-radius: 8px;
    border: 1px solid var(--border);
    box-shadow: var(--shadow);
  }}
  h2 {{
    margin-top: 0;
    padding-bottom: 0.5rem;
    border-bottom: 2px solid var(--accent-weak);
    color: var(--accent);
    font-size: 1.5rem;
  }}
  h3 {{
    margin-top: 1.5rem;
    margin-bottom: 0.5rem;
    color: var(--fg);
    font-size: 1.1rem;
  }}
  dl {{
    display: grid;
    grid-template-columns: max-content 1fr;
    gap: 0.5rem 1rem;
  }}
  dt {{
    font-weight: 600;
    color: var(--muted);
  }}
  dd {{
    margin: 0;
  }}
  ul {{
    margin: 0.5rem 0;
    padding-left: 1.5rem;
  }}
  pre {{
    background: var(--code-bg);
    padding: 0.75rem;
    border-radius: 4px;
    overflow-x: auto;
    font-size: 0.9rem;
  }}
  em {{
    color: var(--muted);
  }}
  .toggle-theme {{
    position: fixed;
    top: 1rem;
    right: 1rem;
    padding: 0.5rem 1rem;
    background: var(--accent);
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 0.9rem;
  }}
  .toggle-theme:hover {{
    opacity: 0.9;
  }}
</style>
</head>
<body>
<button class="toggle-theme" onclick="toggleTheme()">Toggle Theme</button>
<div class="container">
<header>
  <h1>Company OSINT Profile</h1>
  <div class="subtitle">
    <div>Created: {html_escape(p.get("created_at",""))}</div>
    <div>Updated: {html_escape(p.get("updated_at",""))}</div>
  </div>
</header>

<section>
<h2>A. Company Identity</h2>
<dl>
  <dt>Legal Business Name</dt>
  <dd>{maybe(p["identity"].get("legal_business_name",""))}</dd>
  <dt>Parent Company</dt>
  <dd>{maybe(p["identity"].get("parent_company",""))}</dd>
  <dt>Business Number</dt>
  <dd>{maybe(p["identity"].get("registered_business_number",""))}</dd>
  <dt>Registration ID</dt>
  <dd>{maybe(p["identity"].get("corporate_registration_id",""))}</dd>
</dl>
<h3>Alternate Names / DBAs</h3>
{ul(p["identity"].get("alternate_names_dbas",[]))}
<h3>Subsidiaries & Brands</h3>
{ul(p["identity"].get("subsidiaries_brands",[]))}
<h3>Industry Codes (NAICS/SIC)</h3>
{ul(p["identity"].get("industry_naics_sic",[]))}
</section>

<section>
<h2>B. Domains & Internet Footprint</h2>
<dl>
  <dt>Primary Domain</dt>
  <dd>{maybe(p["domains"].get("primary_domain",""))}</dd>
  <dt>Hosting Provider</dt>
  <dd>{maybe(p["domains"].get("hosting_provider",""))}</dd>
  <dt>SSL Issuer</dt>
  <dd>{maybe(p["domains"].get("ssl_issuer",""))}</dd>
</dl>
<h3>Secondary Domains</h3>
{ul(p["domains"].get("secondary_domains",[]))}
<h3>Parked Domains</h3>
{ul(p["domains"].get("parked_domains",[]))}
<h3>TLD Variants</h3>
{ul(p["domains"].get("tld_variants",[]))}
<h3>Known IPs</h3>
{ul(p["domains"].get("known_ips",[]))}
<h3>Typosquatting Variants</h3>
{ul(p["domains"].get("typosquatting_variants",[]))}
</section>

<section>
<h2>C. Addresses & Contact Channels</h2>
<h3>Registered Legal Address</h3>
{pre(p["contacts"].get("registered_legal_address",""))}
<h3>Operating Address</h3>
{pre(p["contacts"].get("operating_address",""))}
<h3>Mailing Address</h3>
{pre(p["contacts"].get("mailing_address",""))}
<dl>
  <dt>Support Phone</dt>
  <dd>{maybe(p["contacts"].get("support_phone_number",""))}</dd>
  <dt>Corporate Phone</dt>
  <dd>{maybe(p["contacts"].get("corporate_phone_number",""))}</dd>
</dl>
<h3>Customer Support Emails</h3>
{ul(p["contacts"].get("customer_support_emails",[]))}
<h3>Sales Emails</h3>
{ul(p["contacts"].get("sales_emails",[]))}
</section>

<section>
<h2>D. Key People</h2>
<h3>Executives</h3>
{ul(p["people"].get("executives",[]))}
<h3>Founders</h3>
{ul(p["people"].get("founders",[]))}
<h3>Board Members</h3>
{ul(p["people"].get("board_members",[]))}
<h3>Corporate Officers</h3>
{ul(p["people"].get("corporate_officers",[]))}
<h3>Security/IT Leaders</h3>
{ul(p["people"].get("security_it_leaders",[]))}
<h3>Public-Facing Employees</h3>
{ul(p["people"].get("public_facing_employees",[]))}
</section>

<section>
<h2>E. Platforms & Digital Presence</h2>
<dl>
  <dt>LinkedIn</dt>
  <dd>{maybe(p["platforms"].get("linkedin",""))}</dd>
  <dt>Twitter/X</dt>
  <dd>{maybe(p["platforms"].get("twitter_x",""))}</dd>
  <dt>Facebook</dt>
  <dd>{maybe(p["platforms"].get("facebook",""))}</dd>
  <dt>Instagram</dt>
  <dd>{maybe(p["platforms"].get("instagram",""))}</dd>
  <dt>YouTube</dt>
  <dd>{maybe(p["platforms"].get("youtube",""))}</dd>
  <dt>GitHub</dt>
  <dd>{maybe(p["platforms"].get("github_org",""))}</dd>
</dl>
<h3>Product Pages</h3>
{ul(p["platforms"].get("product_pages",[]))}
<h3>API Endpoints</h3>
{ul(p["platforms"].get("api_endpoints",[]))}
<h3>Mobile Apps (Android)</h3>
{ul(p["platforms"].get("mobile_apps_android",[]))}
<h3>Mobile Apps (iOS)</h3>
{ul(p["platforms"].get("mobile_apps_ios",[]))}
</section>

<section>
<h2>F. Financial Footprint</h2>
<h3>Investors</h3>
{ul(p["financial"].get("investors",[]))}
<h3>Funding Rounds</h3>
{ul(p["financial"].get("funding_rounds",[]))}
<h3>Payment Processors</h3>
{ul(p["financial"].get("payment_processors",[]))}
<h3>Banking Partners</h3>
{ul(p["financial"].get("banking_partners",[]))}
</section>

<section>
<h2>G. High-Level Security Context</h2>
<dl>
  <dt>Regulated Industry</dt>
  <dd>{maybe(p["security"].get("regulated_industry",""))}</dd>
</dl>
<h3>Known Breaches</h3>
{ul(p["security"].get("known_breaches",[]))}
<h3>News References</h3>
{ul(p["security"].get("news_references",[]))}
<h3>Known Phishing Domains</h3>
{ul(p["security"].get("known_phishing_domains",[]))}
</section>

</div>

<script>
function toggleTheme() {{
  const body = document.body;
  const current = body.getAttribute('data-theme');
  const next = current === 'dark' ? 'light' : 'dark';
  body.setAttribute('data-theme', next);
  localStorage.setItem('theme', next);
}}

// Apply saved theme on load
const saved = localStorage.getItem('theme');
if (saved) {{
  document.body.setAttribute('data-theme', saved);
}} else if (window.matchMedia('(prefers-color-scheme: dark)').matches) {{
  document.body.setAttribute('data-theme', 'dark');
}}
</script>
</body>
</html>
"""

# --------------------------- Commands --------------------------------

def ensure_project_dir(user_path: Optional[str]) -> Path:
    if user_path:
        root = Path(user_path)
    else:
        root = Path.cwd()
    root.mkdir(parents=True, exist_ok=True)
    return root.resolve()

def default_paths(root: Path) -> Dict[str, Path]:
    return {
        "profile": root / "profile.json",
        "reports": root / "reports" / "report.html",
    }

@log_exceptions
def cmd_init(args: argparse.Namespace) -> None:
    root = ensure_project_dir(args.project)
    setup_logging(root, args.debug)
    paths = default_paths(root)
    use_color = not getattr(args, "no_color", False)

    if paths["profile"].exists() and not args.force:
        print(colorize(f"Profile already exists at {paths['profile']}", "yellow", use_color))
        print(colorize("Use --force to overwrite or pick a different project directory.", "yellow", use_color))
        sys.exit(1)

    profile = CompanyProfile()
    save_profile(profile, paths["profile"], pretty=True)
    print(colorize(f"✓ Initialized new profile: {paths['profile']}", "green", use_color))

    if not args.skip_collect:
        if yes_no("Launch wizard now?", True, use_color):
            args.func = cmd_wizard
            cmd_wizard(args)

@log_exceptions
def cmd_start(args: argparse.Namespace) -> None:
    """One-shot: init + wizard, with optional report generation and browser opening."""
    root = ensure_project_dir(args.project)
    setup_logging(root, args.debug)
    paths = default_paths(root)
    use_color = not getattr(args, "no_color", False)

    if args.new or not paths["profile"].exists():
        if args.new:
            ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            root = Path.cwd() / f"investigation_{ts}"
            root.mkdir(parents=True, exist_ok=True)
            paths = default_paths(root)
        profile = CompanyProfile()
        save_profile(profile, paths["profile"], pretty=True)
        print(colorize(f"✓ Created new profile: {paths['profile']}", "green", use_color))
    else:
        print(colorize(f"Using existing profile: {paths['profile']}", "cyan", use_color))

    # Launch wizard
    args.func = cmd_wizard
    args.project = str(root)
    cmd_wizard(args)

    # Optionally generate report
    if args.report or args.open:
        profile = load_profile(paths["profile"])
        html_str = render_html_report(profile)
        paths["reports"].parent.mkdir(parents=True, exist_ok=True)
        paths["reports"].write_text(html_str, encoding="utf-8")
        print(colorize(f"✓ Report generated: {paths['reports']}", "green", use_color))

        if args.open:
            webbrowser.open(paths["reports"].as_uri())
            print(colorize("✓ Opened report in browser.", "green", use_color))

@log_exceptions
def cmd_collect(args: argparse.Namespace) -> None:
    root = ensure_project_dir(args.project)
    setup_logging(root, args.debug)
    paths = default_paths(root)
    profile = load_profile(paths["profile"])

    sections_map = {
        "A": ("identity", collect_identity),
        "B": ("domains", collect_domains),
        "C": ("contacts", collect_contacts),
        "D": ("people", collect_people),
        "E": ("platforms", collect_platforms),
        "F": ("financial", collect_financial),
        "G": ("security", collect_security),
    }

    target = args.section or "ALL"
    if target == "ALL":
        for code, (attr, func) in sections_map.items():
            print(f"\n=== Section {code} ===")
            setattr(profile, attr, func(getattr(profile, attr)))
    else:
        if target not in sections_map:
            print(f"Unknown section: {target}")
            sys.exit(1)
        attr, func = sections_map[target]
        setattr(profile, attr, func(getattr(profile, attr)))

    save_profile(profile, paths["profile"], pretty=not args.minify)
    print(f"Profile saved: {paths['profile']}")

@log_exceptions
def cmd_show(args: argparse.Namespace) -> None:
    root = ensure_project_dir(args.project)
    setup_logging(root, args.debug)
    paths = default_paths(root)
    profile = load_profile(paths["profile"])

    print("=== Company Profile Summary ===")
    print(f"Name: {profile.identity.legal_business_name or '(not set)'}")
    print(f"Domain: {profile.domains.primary_domain or '(not set)'}")
    print(f"Created: {profile.created_at}")
    print(f"Updated: {profile.updated_at}")

@log_exceptions
def cmd_export(args: argparse.Namespace) -> None:
    root = ensure_project_dir(args.project)
    setup_logging(root, args.debug)
    paths = default_paths(root)
    profile = load_profile(paths["profile"])

    did_any = False
    if args.json:
        out = Path(args.json)
        save_profile(profile, out, pretty=args.pretty)
        print(f"JSON exported: {out}")
        did_any = True

    if args.python:
        out = Path(args.python)
        export_python_vars(profile, out)
        print(f"Python variables exported: {out}")
        did_any = True

    if not did_any:
        export_dir = (root / "exports")
        export_dir.mkdir(exist_ok=True, parents=True)
        json_out = export_dir / "profile.json"
        py_out = export_dir / "profile_vars.py"
        save_profile(profile, json_out, pretty=True)
        export_python_vars(profile, py_out)
        print(f"Exported:\n- {json_out}\n- {py_out}")

@log_exceptions
def cmd_report(args: argparse.Namespace) -> None:
    root = ensure_project_dir(args.project)
    setup_logging(root, args.debug)
    paths = default_paths(root)
    profile = load_profile(paths["profile"])

    html_str = render_html_report(profile)
    out = Path(args.out) if args.out else paths["reports"]
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(html_str, encoding="utf-8")
    logging.info("HTML report generated at %s", out)
    print(f"Report: {out}")

@log_exceptions
def cmd_plugins(args: argparse.Namespace) -> None:
    """Dynamically load a module:function and pass the CompanyProfile dict."""
    root = ensure_project_dir(args.project)
    setup_logging(root, args.debug)
    paths = default_paths(root)
    profile = load_profile(paths["profile"]).to_dict()

    if ":" not in args.module:
        logging.error("Use MODULE_PATH:FUNCTION format, e.g., mypkg.mod:run")
        sys.exit(2)
    mod_path, func_name = args.module.split(":", 1)
    mod = importlib.import_module(mod_path)
    func = getattr(mod, func_name, None)
    if not callable(func):
        logging.error("Function %s not found or not callable in %s", func_name, mod_path)
        sys.exit(2)
    logging.info("Invoking plugin %s:%s", mod_path, func_name)
    func(profile)

# --------------------------- Wizard UX -------------------------------

def wizard_sections() -> List[Tuple[str, str]]:
    return [
        ("A", "Company Identity"),
        ("B", "Domains & Internet Footprint"),
        ("C", "Addresses & Contact Channels"),
        ("D", "Key People"),
        ("E", "Platforms & Digital Presence"),
        ("F", "Financial Footprint"),
        ("G", "High-Level Security Context"),
    ]

def wizard_fill_section(code: str, profile: CompanyProfile, use_color: bool) -> CompanyProfile:
    if code == "A":
        ui_section("A. Company Identity", "Legal names and corporate data", use_color)
        ci = profile.identity
        ci.legal_business_name = input(colorize("\n[1] Legal business name: ", "cyan", use_color)).strip() or ci.legal_business_name
        ci.alternate_names_dbas = prompt_list_iterative("Alternate names / DBAs", 2, ci.alternate_names_dbas, None, "One per line", use_color)
        ci.parent_company = input(colorize("\n[3] Parent company: ", "cyan", use_color)).strip() or ci.parent_company
        ci.subsidiaries_brands = prompt_list_iterative("Subsidiaries / brands", 4, ci.subsidiaries_brands, None, "One per line", use_color)
        ci.registered_business_number = input(colorize("\n[5] Registered business number: ", "cyan", use_color)).strip() or ci.registered_business_number
        ci.corporate_registration_id = input(colorize("\n[6] Corporate registration ID (jurisdiction-specific): ", "cyan", use_color)).strip() or ci.corporate_registration_id
        ci.industry_naics_sic = prompt_list_iterative("Industry (NAICS/SIC)", 7, ci.industry_naics_sic, None, "e.g., 541511, 518210", use_color)
        profile.identity = ci
        return profile

    if code == "B":
        ui_section("B. Domains & Internet Footprint", "Domains, IPs, hosting, SSL", use_color)
        d = profile.domains
        pd = input(colorize("\n[1] Primary domain: ", "cyan", use_color)).strip().lower()
        if pd:
            if not valid_domain(pd):
                print(colorize("     └─ ✖ invalid domain; keeping previous.", "red", use_color))
            else:
                d.primary_domain = pd
        d.secondary_domains = clean_domains(prompt_list_iterative("Secondary domains", 2, d.secondary_domains, valid_domain, "example.org, sub.example.com", use_color))
        d.parked_domains = clean_domains(prompt_list_iterative("Parked domains", 3, d.parked_domains, valid_domain, "domains owned but unused", use_color))
        d.tld_variants = clean_domains(prompt_list_iterative("All TLD variants", 4, d.tld_variants, valid_domain, "example.io, example.net", use_color))
        d.known_ips = clean_ips(prompt_list_iterative("Known IPs", 5, d.known_ips, valid_ip, "IPv4/IPv6, e.g., 93.184.216.34", use_color))
        d.hosting_provider = input(colorize("\n[6] Hosting provider: ", "cyan", use_color)).strip() or d.hosting_provider
        d.ssl_issuer = input(colorize("\n[7] SSL issuer: ", "cyan", use_color)).strip() or d.ssl_issuer
        if d.primary_domain:
            auto_typos = gen_typosquats(d.primary_domain, 50)
            merged = sorted(set(d.typosquatting_variants).union(auto_typos))
            print(colorize(f"\n     └─ Generated {len(auto_typos)} typosquatting suggestions.", "dim", use_color))
            d.typosquatting_variants = clean_domains(prompt_list_iterative("Typosquatting variants (review/add/remove)", 8, merged, valid_domain, "Use 'del n' to remove suggestions", use_color))
        profile.domains = d
        return profile

    if code == "C":
        ui_section("C. Addresses & Contact Channels", "Physical addresses, emails, phones", use_color)
        c = profile.contacts
        print(colorize("\n[1] Registered legal address (multi-line; empty line to finish):", "cyan", use_color))
        c.registered_legal_address = prompt_multiline("", c.registered_legal_address)
        print(colorize("\n[2] Operating address (multi-line; empty line to finish):", "cyan", use_color))
        c.operating_address = prompt_multiline("", c.operating_address)
        print(colorize("\n[3] Mailing address (multi-line; empty line to finish):", "cyan", use_color))
        c.mailing_address = prompt_multiline("", c.mailing_address)
        c.customer_support_emails = prompt_list_iterative("Customer support email(s)", 4, c.customer_support_emails, None, "user@domain.tld", use_color)
        c.sales_emails = prompt_list_iterative("Sales email(s)", 5, c.sales_emails, None, "sales@domain.tld", use_color)
        c.support_phone_number = input(colorize("\n[6] Support phone number: ", "cyan", use_color)).strip() or c.support_phone_number
        c.corporate_phone_number = input(colorize("\n[7] Corporate phone number: ", "cyan", use_color)).strip() or c.corporate_phone_number
        profile.contacts = c
        return profile

    if code == "D":
        ui_section("D. Key People", "Executives, founders, officers", use_color)
        p = profile.people
        p.executives = prompt_list_iterative("Executives", 1, p.executives, None, "Name, Title", use_color)
        p.founders = prompt_list_iterative("Founders", 2, p.founders, None, "Name", use_color)
        p.board_members = prompt_list_iterative("Board members", 3, p.board_members, None, "Name", use_color)
        p.corporate_officers = prompt_list_iterative("Corporate officers", 4, p.corporate_officers, None, "Name, Role", use_color)
        p.security_it_leaders = prompt_list_iterative("Security/IT leaders", 5, p.security_it_leaders, None, "Name, Role", use_color)
        p.public_facing_employees = prompt_list_iterative("Public-facing employees", 6, p.public_facing_employees, None, "Name/Persona", use_color)
        profile.people = p
        return profile

    if code == "E":
        ui_section("E. Platforms & Digital Presence", "Socials, products, APIs, apps", use_color)
        pl = profile.platforms
        pl.linkedin = input(colorize("\n[1] Official LinkedIn: ", "cyan", use_color)).strip() or pl.linkedin
        pl.twitter_x = input(colorize("\n[2] Official Twitter/X: ", "cyan", use_color)).strip() or pl.twitter_x
        pl.facebook = input(colorize("\n[3] Facebook: ", "cyan", use_color)).strip() or pl.facebook
        pl.instagram = input(colorize("\n[4] Instagram: ", "cyan", use_color)).strip() or pl.instagram
        pl.youtube = input(colorize("\n[5] YouTube: ", "cyan", use_color)).strip() or pl.youtube
        pl.github_org = input(colorize("\n[6] GitHub org: ", "cyan", use_color)).strip() or pl.github_org
        pl.product_pages = prompt_list_iterative("Product pages (URLs)", 7, pl.product_pages, None, "https://...", use_color)
        pl.api_endpoints = prompt_list_iterative("API endpoints (base URLs)", 8, pl.api_endpoints, None, "https://api.example.com/v1", use_color)
        pl.mobile_apps_android = prompt_list_iterative("Mobile apps (Android)", 9, pl.mobile_apps_android, None, "Play link or package", use_color)
        pl.mobile_apps_ios = prompt_list_iterative("Mobile apps (iOS)", 10, pl.mobile_apps_ios, None, "App Store link or bundle id", use_color)
        profile.platforms = pl
        return profile

    if code == "F":
        ui_section("F. Financial Footprint", "Investors, funding, payments, banks", use_color)
        f = profile.financial
        f.investors = prompt_list_iterative("Investors", 1, f.investors, None, "Firm, Angel, etc.", use_color)
        f.funding_rounds = prompt_list_iterative("Funding rounds", 2, f.funding_rounds, None, "Round, Date, Amount", use_color)
        f.payment_processors = prompt_list_iterative("Payment processors", 3, f.payment_processors, None, "Stripe, Adyen, etc.", use_color)
        f.banking_partners = prompt_list_iterative("Banking partners", 4, f.banking_partners, None, "If disclosed", use_color)
        profile.financial = f
        return profile

    if code == "G":
        ui_section("G. High-Level Security Context", "Regulatory, breaches, phishing", use_color)
        s = profile.security
        s.regulated_industry = input(colorize("\n[1] Regulated industry? (yes/no/unknown + details): ", "cyan", use_color)).strip() or s.regulated_industry
        s.known_breaches = prompt_list_iterative("Known breaches (notes/links)", 2, s.known_breaches, None, "Short notes or URLs", use_color)
        s.news_references = prompt_list_iterative("News references (URLs/titles)", 3, s.news_references, None, "https://... or 'Title - Source'", use_color)
        s.known_phishing_domains = clean_domains(prompt_list_iterative("Known phishing domains", 4, s.known_phishing_domains, valid_domain, "attacker-example.tld", use_color))
        profile.security = s
        return profile

    return profile

@log_exceptions
def cmd_wizard(args: argparse.Namespace) -> None:
    root = ensure_project_dir(args.project)
    setup_logging(root, args.debug)
    paths = default_paths(root)
    use_color = not getattr(args, "no_color", False)

    profile = load_profile(paths["profile"])

    ui_title("Company OSINT Profile Wizard", use_color)
    print(colorize("Navigate: enter section number to fill it. Type 'done' to finish; 'all' to go sequentially.\n", "dim", use_color))
    secs = wizard_sections()
    total = len(secs)

    def calc_completed(p: CompanyProfile) -> int:
        count = 0
        if p.identity.legal_business_name: count += 1
        if p.domains.primary_domain: count += 1
        if p.contacts.customer_support_emails or p.contacts.support_phone_number: count += 1
        if p.people.executives: count += 1
        if p.platforms.linkedin or p.platforms.twitter_x: count += 1
        if p.financial.investors or p.financial.funding_rounds: count += 1
        if p.security.regulated_industry: count += 1
        return count

    while True:
        print()
        ui_progress(calc_completed(profile), total, use_color)
        print()
        
        # Menu with double-line border
        print(colorize("╔═════════════════════════════════════════════════╗", "cyan", use_color))
        for i, (code, label) in enumerate(secs, 1):
            print(colorize(f"║  {i}. [{code}] {label:<39} ║", "cyan", use_color))
        print(colorize("╚═════════════════════════════════════════════════╝", "cyan", use_color))

        print()
        choice = input(colorize("Select a section (1-7), 'all', or 'done': ", "yellow", use_color)).strip().lower()
        if choice in ("done","q","quit","exit"):
            break
        if choice == "all":
            for code, _ in secs:
                profile = wizard_fill_section(code, profile, use_color)
                save_profile(profile, paths["profile"], pretty=True)
                print(colorize("\n  ✓ Section saved.", "green", use_color))
            continue
        try:
            idx = int(choice)
            if not (1 <= idx <= len(secs)):
                print(colorize("Invalid choice.", "red", use_color)); continue
            code = secs[idx-1][0]
            profile = wizard_fill_section(code, profile, use_color)
            save_profile(profile, paths["profile"], pretty=True)
            print(colorize("\n  ✓ Section saved.", "green", use_color))
        except ValueError:
            print(colorize("Please enter a number, 'all', or 'done'.", "red", use_color))

    print()
    print(colorize("Wizard complete.", "green", use_color))
    if yes_no("Generate HTML report now?", True, use_color):
        html_str = render_html_report(profile)
        out = paths["reports"]
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(html_str, encoding="utf-8")
        print(colorize(f"Report: {out}", "green", use_color))

# ------------------------------ Main ---------------------------------

def build_parser() -> argparse.ArgumentParser:
    # Common flags allowed both before and after subcommands
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--project", help="Project directory (will be created if missing)")
    common.add_argument("--debug", action="store_true", help="Enable debug logging")
    common.add_argument("--no-color", action="store_true", help="Disable colored output in wizard UI")

    p = argparse.ArgumentParser(
        prog="profile.py",
        description="Company OSINT Profile CLI",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
        parents=[common],
    )

    sub = p.add_subparsers(dest="cmd", required=True)

    sp_init = sub.add_parser("init", help="Initialize a new project", parents=[common])
    sp_init.add_argument("--force", action="store_true", help="Overwrite existing profile.json")
    sp_init.add_argument("--skip-collect", action="store_true", help="Do not launch wizard after init")
    sp_init.set_defaults(func=cmd_init)

    sp_collect = sub.add_parser("collect", help="Classic interactive mode (comma-separated lists)", parents=[common])
    sp_collect.add_argument("--section", choices=list("ABCDEFG") + ["ALL"], help="Collect only a specific section")
    sp_collect.add_argument("--minify", action="store_true", help="Minify JSON on save")
    sp_collect.set_defaults(func=cmd_collect)

    sp_wizard = sub.add_parser("wizard", help="Friendly guided UI (colors, validation, autosave)", parents=[common])
    sp_wizard.set_defaults(func=cmd_wizard)

    sp_show = sub.add_parser("show", help="Show a brief summary", parents=[common])
    sp_show.set_defaults(func=cmd_show)

    sp_export = sub.add_parser("export", help="Export JSON/Python variables", parents=[common])
    sp_export.add_argument("--json", help="Path for JSON export")
    sp_export.add_argument("--python", help="Path for Python variables export (e.g., ./out/profile_vars.py)")
    sp_export.add_argument("--pretty", action="store_true", help="Pretty-print JSON (if exporting JSON)")
    sp_export.set_defaults(func=cmd_export)

    sp_report = sub.add_parser("report", help="Generate HTML report", parents=[common])
    sp_report.add_argument("--out", help="Output HTML path")
    sp_report.set_defaults(func=cmd_report)

    sp_plugins = sub.add_parser("plugins", help="Run a plugin module:function with the profile", parents=[common])
    sp_plugins.add_argument("--module", required=True, help="Import path, e.g., mypkg.module:run")
    sp_plugins.set_defaults(func=cmd_plugins)

    # NEW: start (one-shot init + wizard)
    sp_start = sub.add_parser(
        "start",
        help="Create a new investigation (init if needed) and launch the wizard",
        parents=[common],
    )
    sp_start.add_argument(
        "--new",
        action="store_true",
        help="Always create a fresh timestamped project directory (even if one exists)",
    )
    sp_start.add_argument(
        "--report",
        action="store_true",
        help="Generate an HTML report after completing the wizard",
    )
    sp_start.add_argument(
        "--open",
        action="store_true",
        help="Open the generated report in your default browser (use with --report)",
    )
    sp_start.set_defaults(func=cmd_start)

    return p

@log_exceptions
def main(argv: Optional[List[str]] = None) -> None:
    args = build_parser().parse_args(argv)
    root = ensure_project_dir(getattr(args, "project", None))
    setup_logging(root, getattr(args, "debug", False))
    logging.debug("Arguments: %s", vars(args))
    args.func(args)

if __name__ == "__main__":
    main()