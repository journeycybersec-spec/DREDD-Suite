# file: osint_webapp.py
"""
FastAPI + HTMX frontend (Dark Theme).
Updates:
- New Investigation: collapsed by default
- All user-input fields are expandable (textarea, vertical resize), label above control
- Removed per-field collapsibles
"""
from __future__ import annotations
import json, os, threading, time, datetime
from pathlib import Path
from queue import Queue, Empty
from typing import Dict, Optional, Any

from fastapi import FastAPI, HTTPException, Request, UploadFile, File, Form, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, JSONResponse, PlainTextResponse
from fastapi.middleware.cors import CORSMiddleware

# Optional project imports (guarded)
try:
    import profile as profile_mod  # profile.py: CompanyProfile, render_html_report
except Exception:
    profile_mod = None

try:
    from osint_ext.prompt import render_prompt, save_prompt_files
    from osint_ext.validator import extract_and_fix_json
    from osint_ext.claude_runner import run_claude
except Exception:
    render_prompt = save_prompt_files = None  # type: ignore
    extract_and_fix_json = None  # type: ignore
    run_claude = None  # type: ignore

try:
    import requests  # Ollama HTTP
except Exception:
    requests = None  # type: ignore

# YAML (optional for import endpoint)
try:
    import yaml  # type: ignore
except Exception:
    yaml = None  # type: ignore

app = FastAPI(title="OSINT Frontend (Dark Theme)")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

INDEX_HTML = """<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>OSINT Frontend</title>
  <script src="https://unpkg.com/htmx.org@1.9.12"></script>
  <style>
    :root {
      --bg: #0b1220; --fg: #e5e7eb; --muted: #94a3b8; --card: #0f172a;
      --border: #1f2937; --accent: #60a5fa; --accent-weak: #1e293b; --code-bg: #0b1220; --shadow: none;
    }
    html, body { height: 100%; }
    body { margin: 0; background: var(--bg); color: var(--fg); font: 16px/1.55 system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial; }
    .wrap { max-width: 1180px; margin: 0 auto; padding: 24px 20px 64px; }
    header.header { display:flex; align-items:center; justify-content:space-between; gap:12px; margin-bottom:16px; }
    h1 { font-size: 2rem; margin:0; color: var(--accent); letter-spacing:.2px; }
    .meta { color: var(--muted); font-size:.9rem; }
    nav.toc { position: sticky; top:0; z-index:5; background:var(--bg); padding:10px 0 12px; margin:8px 0 20px; border-bottom:1px solid var(--border); }
    .toc a { display:inline-block; margin:4px 8px 0 0; padding:6px 10px; border-radius:999px; text-decoration:none; border:1px solid var(--border); background:var(--card); color:var(--fg); font-size:.9rem; }
    .toc a:hover { border-color: var(--accent); color: var(--accent); }
    section.card { border:1px solid var(--border); border-radius:14px; background:var(--card); box-shadow: var(--shadow); padding:18px 18px 14px; margin:16px 0; }
    h2 { font-size: 1.1rem; color: var(--accent); margin:0 0 .6rem 0; display:flex; align-items:center; gap:8px; }
    .badge { font:600 12px/1 system-ui; color:var(--accent); background:var(--accent-weak); border:1px solid var(--border); padding:4px 8px; border-radius:999px; }
    input, textarea, select, button { background:var(--card); color:var(--fg); border:1px solid var(--border); border-radius:10px; padding:8px 10px; font-size:14px; }
    textarea { background: var(--code-bg); border-radius: 12px; }
    .row { display:flex; gap:12px; align-items:center; flex-wrap:wrap; }
    .grow { flex: 1 1 auto; }
    .btn { border:1px solid var(--border); background:var(--card); color:var(--fg); padding:8px 12px; border-radius:10px; cursor:pointer; }
    .btn:hover { border-color: var(--accent); color: var(--accent); }
    .muted { color: var(--muted); }
    .term { background:var(--code-bg); color:var(--fg); padding:12px; min-height:160px; border-radius:12px; overflow:auto; white-space:pre-wrap; border:1px solid var(--border); }
    .stats { color: var(--muted); font-size:.9rem; margin-top:8px; }
    .hint { font-size:.85rem; color: var(--muted); }

    /* Section collapsible (default closed) */
    details.section > summary { list-style:none; cursor:pointer; user-select:none; display:flex; align-items:center; gap:8px; }
    details.section > summary::-webkit-details-marker { display:none; }
    .twisty { width:10px; height:10px; border:1px solid var(--border); border-radius:2px; display:inline-block; transform: rotate(0deg); transition: transform .15s ease; background: var(--accent-weak); }
    details.section[open] > summary .twisty { transform: rotate(90deg); }

    /* New Investigation field layout */
    .fields { display:grid; grid-template-columns: 1fr; gap:12px; }
    .field { display:block; }
    .field .label { display:block; color: var(--muted); margin-bottom:6px; }
    .expand { 
      resize: both;               /* horizontal + vertical */
      min-height: 42px; 
      width: 50%;                 /* start at half-screen width */
      max-width: none; 
      box-sizing: border-box;
      overflow: auto;
    } 
    .half { margin-left: 0; }   /* indent so the box starts halfway across */
  </style>
</head>
<body>
  <div class="wrap">
    <header class="header">
      <div><h1>OSINT Frontend</h1><div class="meta">Dark theme aligned with report styling</div></div>
      <div class="controls"><span class="muted" id="health">health: …</span></div>
    </header>

    <nav class="toc" aria-label="Table of contents">
      <a href="#new">New</a>
      <a href="#profile">Profile</a>
      <a href="#ai">AI</a>
      <a href="#logs">Logs</a>
    </nav>

    <!-- New Investigation: collapsed by default; inputs are expandable textareas -->
    <section id="new" class="card">
      <details class="section">
        <summary><span class="twisty"></span><h2 style="display:inline-flex;align-items:center;gap:8px;margin:0;">New Investigation <span class="badge">Setup</span></h2></summary>
        <div style="height:10px"></div>

        <div class="fields">
          <div class="field"><span class="label">Project folder</span><textarea id="new_project" class="expand half" rows="1" placeholder="/absolute/path/to/new_project"></textarea></div>

          <!-- Identity -->
          <div class="field"><span class="label">Legal business name</span><textarea id="i_legal" class="expand half" rows="1" placeholder="Acme Corporation"></textarea></div>
          <div class="field"><span class="label">Parent company</span><textarea id="i_parent" class="expand half" rows="1" placeholder="Acme Holdings"></textarea></div>
          <div class="field"><span class="label">DBAs (comma)</span><textarea id="i_dbas" class="expand half" rows="1" placeholder="Acme, Acme Labs"></textarea></div>
          <div class="field"><span class="label">Subsidiaries / brands (comma)</span><textarea id="i_subs" class="expand half" rows="1" placeholder="AcmePay, RocketCo"></textarea></div>
          <div class="field"><span class="label">Registered business number</span><textarea id="i_regnum" class="expand half" rows="1" placeholder="1234567"></textarea></div>
          <div class="field"><span class="label">Corporate registration ID</span><textarea id="i_corpreg" class="expand half" rows="1" placeholder="DE-AB-2020-001"></textarea></div>
          <div class="field"><span class="label">Industry codes (NAICS/SIC, comma)</span><textarea id="i_codes" class="expand half" rows="1" placeholder="NAICS 541511, SIC 7371"></textarea></div>

          <!-- Domains -->
          <div class="field"><span class="label">Primary domain</span><textarea id="d_primary" class="expand half" rows="1" placeholder="example.com"></textarea></div>
          <div class="field"><span class="label">Secondary domains (comma)</span><textarea id="d_secondary" class="expand half" rows="1" placeholder="acme.com, acme.co"></textarea></div>
          <div class="field"><span class="label">Parked domains (comma)</span><textarea id="d_parked" class="expand half" rows="1" placeholder="acme.io, acme.app"></textarea></div>
          <div class="field"><span class="label">TLD variants (comma)</span><textarea id="d_tlds" class="expand half" rows="1" placeholder="acme.net, acme.org"></textarea></div>
          <div class="field"><span class="label">Known IPs (comma)</span><textarea id="d_ips" class="expand half" rows="1" placeholder="1.2.3.4, 5.6.7.8"></textarea></div>
          <div class="field"><span class="label">Hosting provider</span><textarea id="d_host" class="expand half" rows="1" placeholder="AWS"></textarea></div>
          <div class="field"><span class="label">SSL issuer</span><textarea id="d_ssl" class="expand half" rows="1" placeholder="Let's Encrypt"></textarea></div>
          <div class="field"><span class="label">Typosquatting variants (comma)</span><textarea id="d_typos" class="expand half" rows="1" placeholder="examp1e.com, exarnple.com"></textarea></div>

          <!-- Addresses -->
          <div class="field"><span class="label">Registered legal address</span><textarea id="c_regaddr" class="expand half" rows="3" placeholder="123 Main St..."></textarea></div>
          <div class="field"><span class="label">Operating address</span><textarea id="c_opaddr" class="expand half" rows="3" placeholder="Suite 100..."></textarea></div>
          <div class="field"><span class="label">Mailing address</span><textarea id="c_mailaddr" class="expand half" rows="3" placeholder="PO Box..."></textarea></div>

          <!-- Communications -->
          <div class="field"><span class="label">Customer support emails (comma)</span><textarea id="c_cust" class="expand half" rows="1" placeholder="support@acme.com, help@acme.com"></textarea></div>
          <div class="field"><span class="label">Sales emails (comma)</span><textarea id="c_sales" class="expand half" rows="1" placeholder="sales@acme.com"></textarea></div>
          <div class="field"><span class="label">Support phone</span><textarea id="c_sp" class="expand half" rows="1" placeholder="+1 555-0100"></textarea></div>
          <div class="field"><span class="label">Corporate phone</span><textarea id="c_cp" class="expand half" rows="1" placeholder="+1 555-0101"></textarea></div>

          <!-- People -->
          <div class="field"><span class="label">Executives (one per line)</span><textarea id="p_exec" class="expand half" rows="3"></textarea></div>
          <div class="field"><span class="label">Founders (one per line)</span><textarea id="p_found" class="expand half" rows="3"></textarea></div>
          <div class="field"><span class="label">Board members (one per line)</span><textarea id="p_board" class="expand half" rows="3"></textarea></div>
          <div class="field"><span class="label">Corporate officers (one per line)</span><textarea id="p_off" class="expand half" rows="3"></textarea></div>
          <div class="field"><span class="label">Security/IT leaders (one per line)</span><textarea id="p_secit" class="expand half" rows="3"></textarea></div>
          <div class="field"><span class="label">Public-facing employees (one per line)</span><textarea id="p_public" class="expand half" rows="3"></textarea></div>

          <!-- Platforms -->
          <div class="field"><span class="label">LinkedIn</span><textarea id="pl_li" class="expand half" rows="1" placeholder="https://www.linkedin.com/company/acme"></textarea></div>
          <div class="field"><span class="label">Twitter/X</span><textarea id="pl_x" class="expand half" rows="1" placeholder="https://x.com/acme"></textarea></div>
          <div class="field"><span class="label">Facebook</span><textarea id="pl_fb" class="expand half" rows="1" placeholder="https://facebook.com/acme"></textarea></div>
          <div class="field"><span class="label">Instagram</span><textarea id="pl_ig" class="expand half" rows="1" placeholder="https://instagram.com/acme"></textarea></div>
          <div class="field"><span class="label">YouTube</span><textarea id="pl_yt" class="expand half" rows="1" placeholder="https://youtube.com/@acme"></textarea></div>
          <div class="field"><span class="label">GitHub org</span><textarea id="pl_gh" class="expand half" rows="1" placeholder="https://github.com/acme"></textarea></div>
          <div class="field"><span class="label">Product pages (one per line)</span><textarea id="pl_prod" class="expand half" rows="3"></textarea></div>
          <div class="field"><span class="label">API endpoints (one per line)</span><textarea id="pl_api" class="expand half" rows="3"></textarea></div>
          <div class="field"><span class="label">Mobile apps (Android)</span><textarea id="pl_and" class="expand half" rows="3"></textarea></div>
          <div class="field"><span class="label">Mobile apps (iOS)</span><textarea id="pl_ios" class="expand half" rows="3"></textarea></div>

          <!-- Financial -->
          <div class="field"><span class="label">Investors (one per line)</span><textarea id="f_inv" class="expand half" rows="3"></textarea></div>
          <div class="field"><span class="label">Funding rounds (one per line)</span><textarea id="f_rounds" class="expand half" rows="3"></textarea></div>
          <div class="field"><span class="label">Payment processors (one per line)</span><textarea id="f_pay" class="expand half" rows="3"></textarea></div>
          <div class="field"><span class="label">Banking partners (one per line)</span><textarea id="f_bank" class="expand half" rows="3"></textarea></div>

          <!-- Security -->
          <div class="field"><span class="label">Regulated industry? (yes/no/unknown + details)</span><textarea id="s_reg" class="expand half" rows="1" placeholder="unknown"></textarea></div>
          <div class="field"><span class="label">Known breaches (one per line)</span><textarea id="s_breach" class="expand half" rows="3"></textarea></div>
          <div class="field"><span class="label">News references (one per line)</span><textarea id="s_news" class="expand half" rows="3"></textarea></div>
          <div class="field"><span class="label">Known phishing domains (one per line)</span><textarea id="s_phish" class="expand half" rows="3"></textarea></div>

          <div class="row" style="margin-top:6px;">
            <label class="muted"><input id="new_force" type="checkbox" style="vertical-align: middle; margin-right:6px;"/>Overwrite if exists</label>
            <button class="btn" onclick="createInvestigation()">Create</button>
            <div class="hint">Creates folder, writes profile.json, prepares exports/ dirs, auto-selects project.</div>
          </div>
        </div>
      </details>
    </section>

    <!-- Profile -->
    <section id="profile" class="card">
      <h2>Profile <span class="badge">Core</span></h2>
      <div class="row">
        <input id="project" class="grow" placeholder="/absolute/path/to/osint_project"/>
        <button class="btn" onclick="setProject()">Use</button>
        <span class="muted" id="projHint">Folder containing <code>profile.json</code></span>
      </div>
      <div class="row" style="margin-top:8px;">
        <button class="btn" onclick="loadProfile()">Load</button>
        <button class="btn" onclick="saveProfile()">Save</button>
        <button class="btn" onclick="genReport()">Generate Report</button>
      </div>

      <!-- Import Profile -->
      <div class="row" style="margin-top:8px;">
        <input id="importFile" type="file" />
        <label class="muted"><input id="importOverwrite" type="checkbox" style="vertical-align: middle; margin-right:6px;"/>Overwrite existing</label>
        <button class="btn" onclick="importProfile()">Import</button>
        <div class="hint">Accepts JSON; YAML if PyYAML is installed.</div>
      </div>

      <div style="height:8px"></div>
      <textarea id="profileBox" rows="16" placeholder='{"identity": {...}, "domains": {...}, ...}'></textarea>
    </section>

    <!-- AI -->
    <section id="ai" class="card">
      <h2>AI</h2>
      <div class="row" style="margin-top:8px;">
        <button class="btn" onclick="genPrompt()">Generate Prompt</button>
        <select id="templateSel"><option value="">(default template)</option></select>
        <input id="templateFile" type="file"/>
        <button class="btn" onclick="uploadTemplate()">Upload Template</button>
      </div>
      <div class="row" style="margin-top:8px;">
        <select id="model"><option>llama3.1:8b</option><option>phi3.5:3.8b</option><option>qwen2:7b</option></select>
        <input id="temp" style="width:90px" value="0.2"/>
        <button class="btn" onclick="runOllamaWS()">Run Ollama (WebSocket)</button>
        <button class="btn" onclick="runClaude()">Run Claude</button>
        <button class="btn" onclick="validateJson()">Validate JSON</button>
      </div>
      <div class="term" id="stream"></div>
      <div class="stats" id="stats"></div>
    </section>

    <!-- Logs -->
    <section id="logs" class="card">
      <h2>Logs</h2>
      <div id="log" class="term" style="min-height:90px;"></div>
    </section>
  </div>

<script>
  const term = document.getElementById('stream');
  const statsEl = document.getElementById('stats');
  const logbox = document.getElementById('log');
  const proj = document.getElementById('project');
  const profileBox = document.getElementById('profileBox');
  const templateSel = document.getElementById('templateSel');
  const healthEl = document.getElementById('health');

  function appendLog(msg) { logbox.textContent += msg + "\\n"; logbox.scrollTop = logbox.scrollHeight; }
  function ensureProject() { if(!proj.value){ appendLog('⚠ Set a project first.'); return false; } return true; }
  function setProject() { if(!ensureProject()) return; localStorage.setItem('osint_project', proj.value); appendLog("Project set: " + proj.value); refreshTemplates(); }

  function _csv(id){ const v = document.getElementById(id).value || ""; return v.split(',').map(s=>s.trim()).filter(Boolean); }
  function _lines(id){ const v = document.getElementById(id).value || ""; return v.split('\\n').map(s=>s.trim()).filter(Boolean); }

  async function createInvestigation(){
    const payload = {
      project: document.getElementById('new_project').value,
      identity: {
        legal_business_name: document.getElementById('i_legal').value,
        alternate_names_dbas: _csv('i_dbas'),
        parent_company: document.getElementById('i_parent').value,
        subsidiaries_brands: _csv('i_subs'),
        registered_business_number: document.getElementById('i_regnum').value,
        corporate_registration_id: document.getElementById('i_corpreg').value,
        industry_naics_sic: _csv('i_codes')
      },
      domains: {
        primary_domain: (document.getElementById('d_primary').value || '').toLowerCase(),
        secondary_domains: _csv('d_secondary'),
        parked_domains: _csv('d_parked'),
        tld_variants: _csv('d_tlds'),
        known_ips: _csv('d_ips'),
        hosting_provider: document.getElementById('d_host').value,
        ssl_issuer: document.getElementById('d_ssl').value,
        typosquatting_variants: _csv('d_typos')
      },
      contacts: {
        registered_legal_address: document.getElementById('c_regaddr').value,
        operating_address: document.getElementById('c_opaddr').value,
        mailing_address: document.getElementById('c_mailaddr').value,
        customer_support_emails: _csv('c_cust'),
        sales_emails: _csv('c_sales'),
        support_phone_number: document.getElementById('c_sp').value,
        corporate_phone_number: document.getElementById('c_cp').value
      },
      people: {
        executives: _lines('p_exec'),
        founders: _lines('p_found'),
        board_members: _lines('p_board'),
        corporate_officers: _lines('p_off'),
        security_it_leaders: _lines('p_secit'),
        public_facing_employees: _lines('p_public')
      },
      platforms: {
        linkedin: document.getElementById('pl_li').value,
        twitter_x: document.getElementById('pl_x').value,
        facebook: document.getElementById('pl_fb').value,
        instagram: document.getElementById('pl_ig').value,
        youtube: document.getElementById('pl_yt').value,
        github_org: document.getElementById('pl_gh').value,
        product_pages: _lines('pl_prod'),
        api_endpoints: _lines('pl_api'),
        mobile_apps_android: _lines('pl_and'),
        mobile_apps_ios: _lines('pl_ios')
      },
      financial: {
        investors: _lines('f_inv'),
        funding_rounds: _lines('f_rounds'),
        payment_processors: _lines('f_pay'),
        banking_partners: _lines('f_bank')
      },
      security: {
        regulated_industry: document.getElementById('s_reg').value,
        known_breaches: _lines('s_breach'),
        news_references: _lines('s_news'),
        known_phishing_domains: _lines('s_phish')
      },
      force: document.getElementById('new_force').checked
    };
    if(!payload.project){ appendLog('⚠ Project folder is required'); return; }
    try{
      const r = await fetch('/api/init', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload)});
      const msg = await r.text();
      if(!r.ok){ appendLog('Init failed: ' + msg); return; }
      appendLog(msg);
      document.getElementById('project').value = payload.project;
      setProject();
      await loadProfile();
    }catch(e){ appendLog('Init error: ' + e); }
  }

  async function importProfile(){
    if(!ensureProject()) return;
    const f = document.getElementById('importFile').files[0];
    if(!f){ appendLog('Pick a profile file (.json or .yaml/.yml)'); return; }
    const fd = new FormData();
    fd.append('project', proj.value);
    fd.append('overwrite', document.getElementById('importOverwrite').checked ? 'true' : 'false');
    fd.append('file', f);
    try{
      const r = await fetch('/api/import-profile', { method:'POST', body: fd });
      const txt = await r.text();
      if(!r.ok){ appendLog('Import failed: ' + txt); return; }
      appendLog(txt);
      await loadProfile();
    }catch(e){ appendLog('Import error: ' + e); }
  }

  async function pollHealth(){
    try{
      const r = await fetch('/api/health');
      if(r.ok){ healthEl.textContent = 'health: OK'; }
      else { healthEl.textContent = 'health: FAIL'; appendLog('Health check failed: HTTP ' + r.status); }
    }catch(e){ healthEl.textContent = 'health: FAIL'; appendLog('Health check error: ' + e); }
  }

  async function loadProfile() {
    if(!ensureProject()) return;
    try{
      const r = await fetch('/api/profile?project=' + encodeURIComponent(proj.value));
      if(!r.ok){ appendLog('Load failed: ' + (await r.text())); return; }
      const d = await r.json();
      profileBox.value = JSON.stringify(d, null, 2);
      appendLog("Loaded profile.json");
    }catch(e){ appendLog('Load error: ' + e); }
  }

  async function saveProfile() {
    if(!ensureProject()) return;
    try {
      const body = JSON.stringify({ project: proj.value, profile: JSON.parse(profileBox.value) });
      const r = await fetch('/api/profile', { method:'POST', headers:{'Content-Type':'application/json'}, body });
      if(!r.ok){ appendLog('Save failed: ' + (await r.text())); return; }
      appendLog('Saved profile.json');
    } catch(e) { appendLog('Invalid JSON in editor'); }
  }

  async function genReport() {
    if(!ensureProject()) return;
    try{
      const r = await fetch('/api/report', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({project: proj.value}) });
      appendLog(await r.text());
    }catch(e){ appendLog('Report error: ' + e); }
  }

  async function genPrompt() {
    if(!ensureProject()) return;
    try{
      const body = { project: proj.value, template: templateSel.value ? templateSel.value : null };
      const r = await fetch('/api/prompt', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body) });
      appendLog(await r.text());
    }catch(e){ appendLog('Prompt error: ' + e); }
  }

  async function uploadTemplate() {
    if(!ensureProject()) return;
    try{
      const f = document.getElementById('templateFile').files[0];
      if(!f){ appendLog("Pick a template file first (.md)"); return; }
      const fd = new FormData();
      fd.append('project', proj.value);
      fd.append('file', f);
      const r = await fetch('/api/templates/upload', { method:'POST', body: fd });
      appendLog(await r.text());
      refreshTemplates();
    }catch(e){ appendLog('Upload error: ' + e); }
  }

  async function refreshTemplates() {
    if(!ensureProject()) return;
    try{
      const r = await fetch('/api/templates?project=' + encodeURIComponent(proj.value));
      if(!r.ok){ appendLog('List templates failed: ' + (await r.text())); return; }
      const list = await r.json();
      templateSel.innerHTML = '<option value="">(default template)</option>';
      for(const t of list){ const opt = document.createElement('option'); opt.value=t.path; opt.textContent=t.name; templateSel.appendChild(opt); }
      appendLog('Templates loaded: ' + list.length);
    }catch(e){ appendLog('Templates error: ' + e); }
  }

  function runOllamaWS() {
    if(!ensureProject()) return;
    term.textContent = ""; statsEl.textContent = "";
    const qp = new URLSearchParams({ project: proj.value, model: document.getElementById('model').value, temp: document.getElementById('temp').value, template: templateSel.value || "" });
    const proto = location.protocol === 'https:' ? 'wss' : 'ws';
    const ws = new WebSocket(proto + '://' + location.host + '/ws/ollama?' + qp.toString());
    ws.onmessage = (ev) => {
      try {
        const obj = JSON.parse(ev.data);
        if(obj.type === 'chunk'){ term.textContent += obj.text; term.scrollTop = term.scrollHeight; statsEl.textContent = 'elapsed ' + obj.elapsed.toFixed(1) + 's · tokens ~' + obj.tokens + ' · ' + obj.tps.toFixed(1) + ' tok/s'; }
        else if(obj.type === 'done'){ statsEl.textContent += ' · done'; ws.close(); }
        else if(obj.type === 'error'){ appendLog('[error] ' + obj.message); ws.close(); }
      } catch { term.textContent += ev.data; }
    };
    ws.onerror = () => { appendLog("WebSocket error"); };
    ws.onclose = () => { appendLog("Ollama stream closed"); };
  }

  async function runClaude() {
    if(!ensureProject()) return;
    term.textContent = "";
    try{
      const r = await fetch('/api/run/claude', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({project: proj.value, template: templateSel.value || null}) });
      term.textContent = await r.text();
    }catch(e){ appendLog('Claude error: ' + e); }
  }

  async function validateJson() {
    if(!ensureProject()) return;
    try{
      const r = await fetch('/api/validate', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({project: proj.value}) });
      appendLog(await r.text());
    }catch(e){ appendLog('Validate error: ' + e); }
  }

  (function init(){
    const saved = localStorage.getItem('osint_project');
    if(saved){ proj.value = saved; appendLog("Project set: " + saved); refreshTemplates(); }
    pollHealth(); setInterval(pollHealth, 2000);
  })();
</script>
</body>
</html>
"""

# ---------- Helpers ----------
def _proj_path(p: str) -> Path:
    path = Path(p).expanduser().resolve()
    if not path.exists():
        raise HTTPException(404, f"Project not found: {path}")
    return path

def _load_profile_json(p: Path) -> Dict:
    f = p / "profile.json"
    if not f.exists():
        raise HTTPException(404, f"Missing profile.json at: {f}")
    try:
        return json.loads(f.read_text(encoding="utf-8"))
    except Exception as e:
        raise HTTPException(400, f"Invalid profile.json: {e}")

def _save_profile_json(p: Path, data: Dict) -> None:
    out = p / "profile.json"
    out.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")

def _ensure_exports_dirs(p: Path):
    exports = p / "exports"; prompts = exports / "prompts"; ai = exports / "ai"
    for d in (exports, prompts, ai): d.mkdir(parents=True, exist_ok=True)
    return {"exports": exports, "prompts": prompts, "ai": ai}

def _templates_dir(p: Path) -> Path:
    t = p / "exports" / "prompts" / "templates"
    t.mkdir(parents=True, exist_ok=True)
    return t

# ---------- Routes ----------
@app.get("/", response_class=HTMLResponse)
def index() -> str:
    return INDEX_HTML

@app.get("/api/health")
def api_health():
    return {"ok": True}

@app.post("/api/init")
async def api_init(req: Request):
    body = await req.json()
    project = str(body.get("project") or "").strip()
    if not project:
        raise HTTPException(400, "project is required")
    root = Path(project).expanduser().resolve()
    force = bool(body.get("force") or False)
    root.mkdir(parents=True, exist_ok=True)

    profile: Dict[str, Any] = {
        "identity": body.get("identity") or {},
        "domains": body.get("domains") or {},
        "contacts": body.get("contacts") or {},
        "people": body.get("people") or {},
        "platforms": body.get("platforms") or {},
        "financial": body.get("financial") or {},
        "security": body.get("security") or {},
        "created_at": datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z",
        "updated_at": datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z",
    }

    profile_path = root / "profile.json"
    if profile_path.exists() and not force:
        raise HTTPException(409, f"profile.json already exists at: {profile_path}")
    profile_path.write_text(json.dumps(profile, indent=2, ensure_ascii=False), encoding="utf-8")

    (root / "exports" / "prompts").mkdir(parents=True, exist_ok=True)
    (root / "exports" / "ai").mkdir(parents=True, exist_ok=True)
    (root / "reports").mkdir(parents=True, exist_ok=True)

    return PlainTextResponse(f"New investigation initialized at: {root}\\n- profile.json created")

@app.post("/api/import-profile")
async def api_import_profile(project: str = Form(...), overwrite: str = Form("false"), file: UploadFile = File(...)):
    root = Path(project).expanduser().resolve()
    root.mkdir(parents=True, exist_ok=True)
    dst = root / "profile.json"
    allow_overwrite = overwrite.lower() == "true"
    if dst.exists() and not allow_overwrite:
        raise HTTPException(409, f"profile.json already exists at: {dst}")

    raw = await file.read()
    text = raw.decode("utf-8", errors="replace").strip()
    data = None
    parse_err = None
    try:
        data = json.loads(text)
    except Exception as e:
        parse_err = e
    if data is None and yaml is not None:
        try:
            data = yaml.safe_load(text)
        except Exception as e:
            parse_err = e
    if data is None or not isinstance(data, dict):
        if yaml is None and file.filename and file.filename.lower().endswith((".yaml", ".yml")):
            raise HTTPException(400, "YAML file provided but PyYAML not installed. pip install pyyaml")
        raise HTTPException(400, f"Failed to parse profile file as JSON{' or YAML' if yaml else ''}: {parse_err}")

    try:
        if profile_mod and hasattr(profile_mod, "CompanyProfile"):
            _ = profile_mod.CompanyProfile.from_dict(data)
    except Exception as e:
        raise HTTPException(400, f"profile.json structure invalid for CompanyProfile: {e}")

    dst.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    return PlainTextResponse(f"Imported profile into: {dst}")

@app.get("/api/profile")
def api_get_profile(project: str):
    p = _proj_path(project)
    return JSONResponse(_load_profile_json(p))

@app.post("/api/profile")
async def api_save_profile(req: Request):
    body = await req.json()
    p = _proj_path(body.get("project", ""))
    data = body.get("profile")
    if not isinstance(data, dict):
        raise HTTPException(400, "Body.profile must be an object")
    _save_profile_json(p, data)
    return PlainTextResponse("OK: profile saved")

@app.get("/api/templates")
def api_list_templates(project: str):
    p = _proj_path(project)
    td = _templates_dir(p)
    items = [{"name": f.name, "path": str(f)} for f in td.glob("*.md")]
    return JSONResponse(items)

@app.post("/api/templates/upload")
async def api_upload_template(project: str = Form(...), file: UploadFile = File(...)):
    p = _proj_path(project)
    td = _templates_dir(p)
    name = Path(file.filename or "template.md").name
    if not name.lower().endswith(".md"):
        name += ".md"
    out = td / name
    out.write_bytes(await file.read())
    return PlainTextResponse(f"Uploaded template: {out}")

@app.post("/api/prompt")
async def api_prompt(req: Request):
    if render_prompt is None:
        raise HTTPException(500, "osint_ext.prompt not importable")
    body = await req.json()
    p = _proj_path(body.get("project", ""))
    prof = _load_profile_json(p)
    template = body.get("template") or None
    md = render_prompt(prof, template_path=template)
    _ensure_exports_dirs(p)
    stamped, latest = save_prompt_files(p, md)
    return PlainTextResponse(f"Prompt saved:\\n- {stamped}\\n- {latest} (latest)")

@app.post("/api/report")
async def api_report(req: Request):
    if profile_mod is None or not hasattr(profile_mod, "render_html_report"):
        raise HTTPException(500, "profile.py not importable or missing render_html_report()")
    body = await req.json()
    p = _proj_path(body.get("project", ""))
    prof = _load_profile_json(p)
    html = profile_mod.render_html_report(profile_mod.CompanyProfile.from_dict(prof))
    out = p / "exports" / "report.html"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(html, encoding="utf-8")
    return PlainTextResponse(f"Report generated: {out}")

@app.post("/api/validate")
async def api_validate(req: Request):
    if extract_and_fix_json is None:
        raise HTTPException(500, "osint_ext.validator not importable")
    body = await req.json()
    p = _proj_path(body.get("project", ""))
    dirs = _ensure_exports_dirs(p)
    latest_md = dirs["ai"] / "LATEST_result.md"
    if not latest_md.exists():
        raise HTTPException(404, f"Missing: {latest_md}")
    cleaned = extract_and_fix_json(latest_md.read_text(encoding="utf-8"))
    out_json = dirs["ai"] / f"{latest_md.stem}.json"
    out_json.write_text(json.dumps(cleaned, indent=2, ensure_ascii=False), encoding="utf-8")
    return PlainTextResponse(f"Validated JSON saved:\\n- {out_json}\\n- {dirs['ai'] / 'LATEST_result.json'} (consider creating copy/symlink)")

# ---------- WebSocket streaming (Ollama) ----------
def _stream_ollama_to_queue(project: Path, model: str, temp: float, template_path: Optional[str], q: Queue):
    if requests is None:
        q.put(("error", "Install 'requests' to use Ollama HTTP path.")); return
    host = os.getenv("OLLAMA_HOST", "http://localhost:11434").rstrip("/")
    url = f"{host}/api/generate"
    profile = _load_profile_json(project)
    if render_prompt is None:
        q.put(("error", "osint_ext.prompt not importable")); return
    prompt_md = render_prompt(profile, template_path=template_path)
    try: save_prompt_files(project, prompt_md)
    except Exception: pass
    payload = {"model": model, "prompt": prompt_md, "stream": True, "options": {"temperature": float(temp)}}
    start = time.time(); toks = 0
    try:
        with requests.post(url, json=payload, stream=True, timeout=600) as r:
            r.raise_for_status()
            for line in r.iter_lines(decode_unicode=True):
                if not line: continue
                try: obj = json.loads(line)
                except json.JSONDecodeError: continue
                chunk = obj.get("response", "")
                if chunk:
                    toks += len(chunk.split())
                    elapsed = max(1e-6, time.time() - start)
                    tps = toks / elapsed
                    q.put(("chunk", chunk, elapsed, toks, tps))
                if obj.get("done"): break
        q.put(("done",))
    except Exception as e:
        q.put(("error", str(e)))

@app.websocket("/ws/ollama")
async def ws_ollama(ws: WebSocket, project: str, model: str = "llama3.1:8b", temp: float = 0.2, template: str = ""):
    await ws.accept()
    p = _proj_path(project)
    tpl = template or None
    q: Queue = Queue(maxsize=1024)
    th = threading.Thread(target=_stream_ollama_to_queue, args=(p, model, float(temp), tpl, q), daemon=True)
    th.start()
    try:
        while True:
            try:
                item = q.get(timeout=0.25)
            except Empty:
                await ws.send_text(json.dumps({"type": "tick"}))
                continue
            kind = item[0]
            if kind == "chunk":
                _, text, elapsed, toks, tps = item
                await ws.send_text(json.dumps({"type": "chunk", "text": text, "elapsed": elapsed, "tokens": toks, "tps": tps}))
            elif kind == "done":
                await ws.send_text(json.dumps({"type": "done"})); break
            elif kind == "error":
                await ws.send_text(json.dumps({"type": "error", "message": item[1]})); break
    except WebSocketDisconnect:
        pass

# ---------- Claude (non-stream) ----------
@app.post("/api/run/claude")
async def api_run_claude(req: Request):
    if run_claude is None or render_prompt is None:
        raise HTTPException(500, "Claude or prompt module not importable")
    body = await req.json()
    p = _proj_path(body.get("project", ""))
    prof = _load_profile_json(p)
    md = render_prompt(prof, template_path=body.get("template") or None)
    out = run_claude(md, model=body.get("model") or "claude-3-5-sonnet-latest", temperature=float(body.get("temp") or 0.2))
    dirs = _ensure_exports_dirs(p)
    (dirs["ai"] / "LATEST_result.md").write_text(out, encoding="utf-8")
    return PlainTextResponse(out)
