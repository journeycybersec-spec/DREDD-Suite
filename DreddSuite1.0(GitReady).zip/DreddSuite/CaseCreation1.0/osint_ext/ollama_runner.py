# file: osint_ext/ollama_runner.py
"""
Ollama runner with optional SearXNG integration.
- Builds the base prompt from osint_ext.prompt.render_prompt(profile)
- If searxng is enabled, it searches & fetches pages, then injects a compact
  "External context" block before sending to Ollama's HTTP API.
"""
from __future__ import annotations

import json
import os
import time
import textwrap
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import requests

# Optional project imports
try:
    from .prompt import render_prompt, save_prompt_files
except Exception:
    render_prompt = None  # type: ignore
    save_prompt_files = None  # type: ignore

DEFAULT_OLLAMA = os.getenv("OLLAMA_HOST", "http://localhost:11434").rstrip("/")

def _load_profile_json(project: Path) -> Dict:
    pj = project / "profile.json"
    if not pj.exists():
        raise FileNotFoundError(f"Missing profile.json at: {pj}")
    return json.loads(pj.read_text(encoding="utf-8"))

# ------------------- SearXNG helpers -------------------
def searxng_search(base_url: str, query: str, limit: int = 5, timeout: int = 15) -> List[Dict]:
    """
    Call SearXNG JSON API: <base_url>/search?q=...&format=json
    Returns list of {title, url, content}
    """
    url = f"{base_url.rstrip('/')}/search"
    params = {"q": query, "format": "json", "language": "en", "safesearch": 0}
    r = requests.get(url, params=params, timeout=timeout)
    r.raise_for_status()
    data = r.json()
    out: List[Dict] = []
    for item in data.get("results", [])[:limit]:
        out.append({
            "title": item.get("title") or "",
            "url": item.get("url") or "",
            "content": item.get("content") or item.get("snippet") or ""
        })
    return out

def _fetch_url(url: str, timeout: int = 20, max_chars: int = 2000) -> str:
    try:
        r = requests.get(url, timeout=timeout, headers={"User-Agent": "Mozilla/5.0"})
        r.raise_for_status()
        text = r.text
        # basic strip to avoid huge HTML walls
        return text[:max_chars]
    except Exception as e:
        return f"(fetch error: {e})"

def _build_searx_context(base_url: str, query: str, limit: int, fetch: bool, fetch_timeout: int) -> Tuple[str, List[Dict]]:
    results = searxng_search(base_url, query, limit=limit)
    lines: List[str] = []
    used: List[Dict] = []
    for i, r in enumerate(results, 1):
        body = ""
        if fetch and r["url"]:
            body = _fetch_url(r["url"], timeout=fetch_timeout)
        snippet = r.get("content") or ""
        block = textwrap.dedent(f"""
        [{i}] {r.get('title','').strip()}
        URL: {r.get('url','').strip()}
        Snippet: {snippet.strip()}
        {('---\n'+body.strip()) if body else ''}
        """).strip()
        lines.append(block)
        used.append({"title": r["title"], "url": r["url"], "snippet": snippet, "fetched": bool(body)})
    context = "\n\n".join(lines)
    if context:
        context = "### External context (SearXNG)\n" + context
    return context, used

# ------------------- Runner -------------------
def run_ollama(
    project: str,
    model: str = "llama3.1:8b",
    temperature: float = 0.2,
    template: Optional[str] = None,
    ollama_host: Optional[str] = None,
    # searxng options
    use_searxng: bool = False,
    searxng_url: Optional[str] = None,
    searxng_query: Optional[str] = None,
    searxng_limit: int = 5,
    searxng_fetch: bool = True,
    searxng_fetch_timeout: int = 15,
) -> Dict:
    """
    Returns: {"path_latest": Path, "path_stamped": Path, "response": str, "used_searx": [..]}
    """
    root = Path(project).expanduser().resolve()
    prof = _load_profile_json(root)

    if render_prompt is None:
        raise RuntimeError("osint_ext.prompt.render_prompt not importable")

    base_prompt = render_prompt(prof, template_path=template)
    # Save the base prompt regardless
    if save_prompt_files:
        try:
            save_prompt_files(root, base_prompt)
        except Exception:
            pass

    # Optionally build an external context via SearXNG and prepend
    used_searx: List[Dict] = []
    if use_searxng:
        if not searxng_url:
            raise RuntimeError("use_searxng=True but searxng_url not provided")
        # If no query supplied, derive a reasonable default from profile
        if not searxng_query:
            legal = (prof.get("identity", {}) or {}).get("legal_business_name", "")
            primary_domain = (prof.get("domains", {}) or {}).get("primary_domain", "")
            searxng_query = f'{legal or ""} {primary_domain or ""} data breach security news site:news OR site:blog'
        searx_ctx, used_searx = _build_searx_context(
            searxng_url, searxng_query, limit=searxng_limit, fetch=searxng_fetch, fetch_timeout=searxng_fetch_timeout
        )
        if searx_ctx:
            base_prompt = f"{base_prompt}\n\n{searx_ctx}\n\n" \
                          "Use the External context when relevant. Cite URLs inline.\n"

    # Send to Ollama
    host = (ollama_host or DEFAULT_OLLAMA).rstrip("/")
    payload = {"model": model, "prompt": base_prompt, "stream": False, "options": {"temperature": float(temperature)}}

    t0 = time.time()
    r = requests.post(f"{host}/api/generate", json=payload, timeout=900)
    r.raise_for_status()
    data = r.json()
    response = data.get("response", "")

    # Save outputs
    exports = root / "exports" / "ai"
    exports.mkdir(parents=True, exist_ok=True)
    ts = time.strftime("%Y-%m-%d_%H%M%S")
    stamped = exports / f"{ts}_result.md"
    latest = exports / "LATEST_result.md"

    stamped.write_text(response, encoding="utf-8")
    latest.write_text(response, encoding="utf-8")

    return {
        "path_latest": str(latest),
        "path_stamped": str(stamped),
        "response": response,
        "used_searx": used_searx,
        "duration_s": round(time.time() - t0, 2),
    }
