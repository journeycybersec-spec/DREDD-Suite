# file: osint_ext/ai_cli.py
"""
CLI entry points for AI helpers.
Adds SearXNG options to `run-ollama`.
"""
from __future__ import annotations

import argparse
from pathlib import Path

# Local imports
from .ollama_runner import run_ollama
from .prompt import read_profile, render_prompt, save_prompt_files

def cmd_prompt(args: argparse.Namespace) -> None:
    project = Path(args.project).expanduser().resolve()
    profile = read_profile(project)
    md = render_prompt(profile, template_path=args.template)
    stamped, latest = save_prompt_files(project, md)
    print("Prompt saved:")
    print(f"- {stamped}")
    print(f"- {latest} (latest)")

def cmd_run_ollama(args: argparse.Namespace) -> None:
    print(f"[run-ollama] model={args.model} temp={args.temp} project={args.project}")
    if args.use_searxng:
        print(f"[run-ollama] using SearXNG: url={args.searxng_url} limit={args.searxng_limit} fetch={args.searxng_fetch}")
        if args.searxng_query:
            print(f"[run-ollama] searxng_query={args.searxng_query}")
    out = run_ollama(
        project=args.project,
        model=args.model,
        temperature=args.temp,
        template=args.template,
        ollama_host=args.ollama_host,
        use_searxng=args.use_searxng,
        searxng_url=args.searxng_url,
        searxng_query=args.searxng_query,
        searxng_limit=args.searxng_limit,
        searxng_fetch=not args.no_fetch,
        searxng_fetch_timeout=args.fetch_timeout,
    )
    print("Saved:")
    print(f"- {out['path_stamped']}")
    print(f"- {out['path_latest']} (latest)")

def main() -> None:
    p = argparse.ArgumentParser(prog="osint_ext.ai_cli", description="AI helper CLI")
    sub = p.add_subparsers(dest="cmd", required=True)

    # prompt
    sp = sub.add_parser("prompt", help="Render and save the AI prompt for the project")
    sp.add_argument("--project", required=True, help="Path to project folder")
    sp.add_argument("--template", help="Optional template path (.md)")
    sp.set_defaults(func=cmd_prompt)

    # run-ollama (now with SearXNG)
    so = sub.add_parser("run-ollama", help="Run an Ollama model for the project (optionally with SearXNG)")
    so.add_argument("--project", required=True, help="Path to project folder")
    so.add_argument("--model", required=True, help="Ollama model tag (e.g., llama3.1:8b)")
    so.add_argument("--temp", type=float, default=0.2, help="Sampling temperature")
    so.add_argument("--template", help="Optional template path (.md)")
    so.add_argument("--ollama-host", help="Override OLLAMA_HOST (default env or http://localhost:11434)")

    # SearXNG toggles
    so.add_argument("--use-searxng", action="store_true", help="Enable SearXNG web context")
    so.add_argument("--searxng-url", help="Base URL to your SearXNG (e.g., http://127.0.0.1:8080)")
    so.add_argument("--searxng-query", help="Custom search query; defaults to company/domain context")
    so.add_argument("--searxng-limit", type=int, default=5, help="Max results")
    so.add_argument("--no-fetch", action="store_true", help="Do not fetch pages; use snippets only")
    so.add_argument("--fetch-timeout", type=int, default=15, help="Per-page fetch timeout (sec)")

    so.set_defaults(func=cmd_run_ollama)

    args = p.parse_args()
    args.func(args)

if __name__ == "__main__":
    main()
